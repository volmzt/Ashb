package com.aero.share

import com.aero.share.net.*
import org.junit.Assert.*
import org.junit.Test
import java.io.*

class ProtocolTest {
    @Test fun roundTripLargeSizes() {
        val bos = ByteArrayOutputStream(); val out = DataOutputStream(bos)
        val m = Msg("REQ", transferId = "t1", files = listOf(FileMeta("f1", "a/b.txt", 5_000_000_000L), FileMeta("f2", "c.bin", 7_000_000_000L)))
        Proto.write(out, m)
        val back = Proto.read<Msg>(DataInputStream(ByteArrayInputStream(bos.toByteArray())))
        assertEquals(m, back)
        assertEquals(12_000_000_000L, back.files!!.sumOf { it.size })
    }
    @Test fun oversizedFrameRejected() {
        val bos = ByteArrayOutputStream(); DataOutputStream(bos).writeInt(Proto.MAX_FRAME + 1)
        try { Proto.read<Msg>(DataInputStream(ByteArrayInputStream(bos.toByteArray()))); fail("expected IOException") }
        catch (e: IOException) { }
    }
    @Test fun qrRoundTrip() {
        val p = QrPayload("192.168.1.5", 52525, "tok123", "a".repeat(64), "POCO F6 Pro")
        assertEquals(p, QrPayload.decode(p.encode()))
        assertNull(QrPayload.decode("garbage"))
    }
}
