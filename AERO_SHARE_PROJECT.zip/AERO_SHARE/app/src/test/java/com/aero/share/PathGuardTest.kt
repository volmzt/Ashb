package com.aero.share

import com.aero.share.core.PathGuard
import org.junit.Assert.*
import org.junit.Test

class PathGuardTest {
    @Test fun rejectsTraversal() {
        assertNull(PathGuard.sanitizeRelative("../evil"))
        assertNull(PathGuard.sanitizeRelative("a/../../b"))
        assertNull(PathGuard.sanitizeRelative("/absolute"))
        assertNull(PathGuard.sanitizeRelative("C:/windows"))
        assertNull(PathGuard.sanitizeRelative("a\u0000b"))
        assertNull(PathGuard.sanitizeRelative(""))
    }
    @Test fun acceptsNested() {
        assertEquals("Folder/sub/file.txt", PathGuard.sanitizeRelative("Folder//sub/./file.txt"))
        assertEquals("a/b.apk", PathGuard.sanitizeRelative("a\\b.apk"))
    }
    @Test fun uniqueNames() {
        assertEquals("file (1).txt", PathGuard.uniqueName("file.txt", setOf("file.txt")))
        assertEquals("file (2).txt", PathGuard.uniqueName("file.txt", setOf("file.txt", "file (1).txt")))
        assertEquals("file.txt", PathGuard.uniqueName("file.txt", emptySet()))
    }
}
