package com.aero.share

import com.aero.share.core.Formats
import com.aero.share.core.Hash
import org.junit.Assert.*
import org.junit.Test

class HashFormatsTest {
    @Test fun sha256Vector() {
        assertEquals("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad", Hash.sha256Hex("abc".toByteArray()))
    }
    @Test fun streamingHash() {
        val data = ByteArray(1 shl 20) { (it % 251).toByte() }
        var counted = 0L
        val streamed = Hash.stream(data.inputStream(), ByteArray(64 * 1024)) { counted += it }
        assertEquals(Hash.sha256Hex(data), streamed)
        assertEquals(data.size.toLong(), counted)
    }
    @Test fun formats() {
        assertEquals("0 B", Formats.bytes(0))
        assertEquals("1.0 KB", Formats.bytes(1024))
        assertEquals("1.0 GB", Formats.bytes(1024L * 1024 * 1024))
        assertEquals("1:01", Formats.duration(61_000))
        assertEquals("1:00:00", Formats.duration(3_600_000))
    }
}
