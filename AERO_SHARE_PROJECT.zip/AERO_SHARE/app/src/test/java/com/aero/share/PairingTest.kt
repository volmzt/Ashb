package com.aero.share

import com.aero.share.net.TokenStore
import org.junit.Assert.*
import org.junit.Test

class PairingTest {
    @Test fun singleUse() {
        var now = 0L
        val s = TokenStore { now }
        val t = s.issue(60_000)
        assertTrue(s.consume(t)); assertFalse(s.consume(t)); assertFalse(s.consume("unknown"))
    }
    @Test fun expiry() {
        var now = 0L
        val s = TokenStore { now }
        val t = s.issue(1_000); now = 2_000
        assertFalse(s.consume(t))
    }
}
