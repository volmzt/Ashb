package com.aero.share.core

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Handler
import android.os.Looper
import com.aero.share.data.AppSettings

object Feedback {
    private fun tone(kind: Int) = runCatching {
        val tg = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 70)
        tg.startTone(kind, 140)
        Handler(Looper.getMainLooper()).postDelayed({ tg.release() }, 250)
    }
    fun success(ctx: Context, s: AppSettings) { if (s.sound) tone(ToneGenerator.TONE_PROP_ACK) }
    fun failure(ctx: Context, s: AppSettings) { if (s.sound) tone(ToneGenerator.TONE_PROP_NACK) }
}
