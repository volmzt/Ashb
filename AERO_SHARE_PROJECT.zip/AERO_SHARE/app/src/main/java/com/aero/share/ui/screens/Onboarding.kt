package com.aero.share.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.aero.share.AeroApp
import com.aero.share.R
import com.aero.share.data.ThemeMode
import com.aero.share.ui.*
import kotlinx.coroutines.launch

@Composable
fun Onboarding(app: AeroApp, nav: NavController) {
    val c = aero()
    val scope = rememberCoroutineScope()
    val motion = LocalMotion.current
    val pages = listOf(
        Triple(R.drawable.ic_logo, R.string.onb1_title, R.string.onb1_body),
        Triple(R.drawable.ic_wifi, R.string.onb2_title, R.string.onb2_body),
        Triple(R.drawable.ic_shield, R.string.onb3_title, R.string.onb3_body)
    )
    val pager = rememberPagerState { pages.size + 1 }
    suspend fun go(p: Int) { if (motion) pager.animateScrollToPage(p) else pager.scrollToPage(p) }
    Column(Modifier.fillMaxSize().padding(24.dp)) {
        HorizontalPager(pager, Modifier.weight(1f)) { page ->
            Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                if (page < pages.size) {
                    val (icon, title, body) = pages[page]
                    Icon(painterResource(icon), null, tint = c.accent, modifier = Modifier.size(72.dp))
                    Spacer(Modifier.height(24.dp))
                    Text(stringResource(title), color = c.text, fontSize = 24.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(12.dp))
                    Text(stringResource(body), color = c.text2, textAlign = TextAlign.Center)
                } else {
                    Text(stringResource(R.string.choose_theme), color = c.text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(20.dp))
                    listOf(ThemeMode.SYSTEM to R.string.theme_system, ThemeMode.DARK to R.string.theme_dark,
                        ThemeMode.LIGHT to R.string.theme_light).forEach { (m, label) ->
                        AeroCard(Modifier.fillMaxWidth().padding(vertical = 4.dp).then(AeroClick { scope.launch { app.settings.setTheme(m) } })) {
                            Text(stringResource(label), color = c.text)
                        }
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 16.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            if (pager.currentPage < pages.size) AeroButton(stringResource(R.string.skip), primary = false) { scope.launch { go(pages.size) } }
            else Spacer(Modifier.width(1.dp))
            AeroButton(stringResource(if (pager.currentPage < pages.size) R.string.next else R.string.get_started)) {
                if (pager.currentPage < pages.size) scope.launch { go(pager.currentPage + 1) }
                else scope.launch {
                    app.settings.setOnboarded()
                    nav.navigate("home") { popUpTo("onboarding") { inclusive = true } }
                }
            }
        }
    }
}
