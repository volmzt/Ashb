package com.aero.share.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "devices")
data class DeviceEntity(
    @PrimaryKey val fp: String,
    val id: String,
    val name: String,
    val model: String,
    val alias: String = "",
    val trusted: Boolean = false,
    val blocked: Boolean = false,
    val firstSeen: Long = System.currentTimeMillis(),
    val lastSeen: Long = System.currentTimeMillis()
) { fun display(): String = alias.ifBlank { name } }

@Entity(tableName = "history")
data class HistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val ts: Long,
    val direction: String,
    val peer: String,
    val files: Int,
    val bytes: Long,
    val durationMs: Long,
    val status: String,
    val urisJson: String = "[]"
)

@Dao interface DeviceDao {
    @Query("SELECT * FROM devices ORDER BY lastSeen DESC") fun all(): Flow<List<DeviceEntity>>
    @Query("SELECT * FROM devices WHERE fp = :fp") suspend fun byFp(fp: String): DeviceEntity?
    @Upsert suspend fun upsert(d: DeviceEntity)
    @Query("DELETE FROM devices WHERE fp = :fp") suspend fun delete(fp: String)
}

@Dao interface HistoryDao {
    @Query("SELECT * FROM history ORDER BY ts DESC LIMIT 500") fun all(): Flow<List<HistoryEntity>>
    @Insert suspend fun insert(h: HistoryEntity)
    @Query("DELETE FROM history") suspend fun clear()
}

@Database(entities = [DeviceEntity::class, HistoryEntity::class], version = 1, exportSchema = false)
abstract class AeroDb : RoomDatabase() {
    abstract fun devices(): DeviceDao
    abstract fun history(): HistoryDao
    companion object {
        fun build(ctx: Context): AeroDb = Room.databaseBuilder(ctx, AeroDb::class.java, "aero.db").build()
    }
}

class DeviceRepo(private val dao: DeviceDao) {
    val all: Flow<List<DeviceEntity>> = dao.all()
    suspend fun byFp(fp: String) = dao.byFp(fp)
    suspend fun upsert(d: DeviceEntity) = dao.upsert(d)
    suspend fun delete(fp: String) = dao.delete(fp)
    suspend fun touch(fp: String, id: String, name: String, model: String) {
        val old = dao.byFp(fp)
        dao.upsert(old?.copy(lastSeen = System.currentTimeMillis(), name = name, model = model)
            ?: DeviceEntity(fp = fp, id = id, name = name, model = model))
    }
}

class HistoryRepo(private val dao: HistoryDao) {
    val all: Flow<List<HistoryEntity>> = dao.all()
    suspend fun add(h: HistoryEntity) = dao.insert(h)
    suspend fun clear() = dao.clear()
}
