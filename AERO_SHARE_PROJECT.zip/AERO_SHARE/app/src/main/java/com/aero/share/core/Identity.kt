package com.aero.share.core

import android.content.Context
import android.os.Build
import java.util.UUID

class Identity(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("aero_identity", Context.MODE_PRIVATE)
    val id: String = prefs.getString("id", null) ?: UUID.randomUUID().toString().also {
        prefs.edit().putString("id", it).apply()
    }
    val model: String = Build.MODEL ?: "Android"
    fun name(custom: String): String = custom.ifBlank { model }
}
