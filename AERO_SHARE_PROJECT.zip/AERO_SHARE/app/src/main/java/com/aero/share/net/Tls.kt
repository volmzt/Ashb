package com.aero.share.net

import android.content.Context
import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import com.aero.share.core.Hash
import org.bouncycastle.asn1.x9.X9ObjectIdentifiers
import org.bouncycastle.asn1.x500.X500Name
import org.bouncycastle.asn1.x509.AlgorithmIdentifier
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder
import org.bouncycastle.operator.ContentSigner
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.OutputStream
import java.math.BigInteger
import java.net.Socket
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.Principal
import java.security.PrivateKey
import java.security.SecureRandom
import java.security.Signature
import java.security.cert.CertificateException
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.spec.ECGenParameterSpec
import java.util.Base64
import java.util.Date
import java.util.concurrent.atomic.AtomicReference
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocket
import javax.net.ssl.X509KeyManager
import javax.net.ssl.X509TrustManager

/**
 * Per-device ECDSA P-256 identity. Private key lives in AndroidKeyStore (non-exportable).
 * Self-signed certificate built with BouncyCastle, signed by the KeyStore key.
 * TLS encryption + certificate pinning: QR/manual fingerprint mismatch fails the handshake;
 * discovered devices are confirmed by a short code before any file data is exchanged.
 */
class DeviceTls(private val ctx: Context) {
    companion object { private const val ALIAS = "aero_identity" }
    private val certFile get() = File(ctx.filesDir, "identity.crt")
    val certificate: X509Certificate by lazy { ensure() }
    val fingerprint: String by lazy { Hash.sha256Hex(certificate.encoded) }

    @Synchronized
    private fun ensure(): X509Certificate {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        if (certFile.exists() && ks.containsAlias(ALIAS)) {
            runCatching {
                val der = Base64.getDecoder().decode(certFile.readText().trim())
                return CertificateFactory.getInstance("X.509")
                    .generateCertificate(der.inputStream()) as X509Certificate
            }
        }
        if (!ks.containsAlias(ALIAS)) {
            KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_EC, "AndroidKeyStore").apply {
                initialize(
                    KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_SIGN or KeyProperties.PURPOSE_VERIFY)
                        .setAlgorithmParameterSpec(ECGenParameterSpec("secp256r1"))
                        .setDigests(KeyProperties.DIGEST_SHA256).build()
                )
            }.generateKeyPair()
        }
        val pub = ks.getCertificate(ALIAS).publicKey
        val priv = ks.getKey(ALIAS, null) as PrivateKey
        val signer = object : ContentSigner {
            val buf = ByteArrayOutputStream()
            override fun getAlgorithmIdentifier(): AlgorithmIdentifier =
                AlgorithmIdentifier(X9ObjectIdentifiers.ecdsa_with_SHA256)
            override fun getOutputStream(): OutputStream = buf
            override fun getSignature(): ByteArray = Signature.getInstance("SHA256withECDSA").run {
                initSign(priv); update(buf.toByteArray()); sign()
            }
        }
        val now = System.currentTimeMillis()
        val subject = X500Name("CN=AERO SHARE Device")
        val holder = JcaX509v3CertificateBuilder(
            subject, BigInteger.valueOf(now), Date(now - 86_400_000L),
            Date(now + 3650L * 86_400_000L), subject, SubjectPublicKeyInfo.getInstance(pub.encoded)
        ).build(signer)
        val cert = JcaX509CertificateConverter().getCertificate(holder)
        certFile.writeText(Base64.getEncoder().encodeToString(cert.encoded))
        return cert
    }

    private fun keyManager() = object : X509KeyManager {
        override fun getClientAliases(keyType: String?, issuers: Array<out Principal>?): Array<String> = arrayOf(ALIAS)
        override fun chooseClientAlias(keyType: Array<out String>?, issuers: Array<out Principal>?, socket: Socket?): String = ALIAS
        override fun getServerAliases(keyType: String?, issuers: Array<out Principal>?): Array<String> = arrayOf(ALIAS)
        override fun chooseServerAlias(keyType: String?, issuers: Array<out Principal>?, socket: Socket?): String = ALIAS
        override fun getCertificateChain(alias: String?): Array<X509Certificate> = arrayOf(certificate)
        override fun getPrivateKey(alias: String?): PrivateKey =
            KeyStore.getInstance("AndroidKeyStore").apply { load(null) }.getKey(ALIAS, null) as PrivateKey
    }

    fun context(expectedFp: String?, captured: AtomicReference<String?>): SSLContext {
        val tm = object : X509TrustManager {
            fun verify(chain: Array<X509Certificate>) {
                val fp = Hash.sha256Hex(chain[0].encoded)
                if (expectedFp != null && !fp.equals(expectedFp, ignoreCase = true))
                    throw CertificateException("Fingerprint mismatch")
                captured.set(fp)
            }
            override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) = verify(chain)
            override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) = verify(chain)
            override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
        }
        return SSLContext.getInstance("TLS").apply { init(arrayOf(keyManager()), arrayOf(tm), SecureRandom()) }
    }

    fun applyProtocols(s: SSLSocket) {
        s.enabledProtocols = if (Build.VERSION.SDK_INT >= 29) arrayOf("TLSv1.3", "TLSv1.2") else arrayOf("TLSv1.2")
    }
}
