package com.aero.share.core

import java.io.InputStream
import java.security.MessageDigest

object Hash {
    fun hex(b: ByteArray): String = b.joinToString("") { "%02x".format(it) }
    fun sha256Hex(bytes: ByteArray): String = hex(MessageDigest.getInstance("SHA-256").digest(bytes))
    fun stream(input: InputStream, buf: ByteArray, onChunk: (Int) -> Unit = {}): String {
        val md = MessageDigest.getInstance("SHA-256")
        while (true) {
            val n = input.read(buf)
            if (n < 0) break
            md.update(buf, 0, n)
            onChunk(n)
        }
        return hex(md.digest())
    }
}
