package com.aero.share.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.aero.share.AeroApp
import com.aero.share.R
import com.aero.share.core.Formats
import com.aero.share.net.Dir
import com.aero.share.net.Qr
import com.aero.share.net.QrPayload
import com.aero.share.net.TState
import com.aero.share.ui.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

@Composable
fun Receive(app: AeroApp, nav: NavController) {
    val c = aero(); val ctx = LocalContext.current
    val s by app.settings.flow.collectAsStateWithLifecycle(initialValue = app.settingsNow)
    val port by app.engine.serverPort.collectAsStateWithLifecycle()
    val incoming by app.engine.incoming.collectAsStateWithLifecycle()
    val active by app.engine.active.collectAsStateWithLifecycle()
    var showQr by remember { mutableStateOf(false) }
    var qr by remember { mutableStateOf<android.graphics.Bitmap?>(null) }
    var addr by remember { mutableStateOf<String?>(null) }
    val notifL = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val legacyL = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    DisposableEffect(Unit) {
        app.engine.setReceiveMode(true)
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) notifL.launch(Manifest.permission.POST_NOTIFICATIONS)
        if (Build.VERSION.SDK_INT <= 28 && s.receiveTreeUri.isEmpty() && ContextCompat.checkSelfPermission(ctx, Manifest.permission.WRITE_EXTERNAL_STORAGE) != android.content.pm.PackageManager.PERMISSION_GRANTED) legacyL.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        onDispose { app.engine.setReceiveMode(false) }
    }
    LaunchedEffect(active?.state) { if (active?.state == TState.Transferring && active?.dir == Dir.Receive) nav.navigate("transfer") { launchSingleTop = true } }
    LaunchedEffect(showQr, port, s.qrTtlMin) {
        if (showQr && port > 0) while (true) {
            val host = withContext(Dispatchers.IO) { app.discovery.localAddress() }
            addr = host
            if (host != null) {
                val payload = QrPayload(host, port, app.engine.tokens.issue(s.qrTtlMin * 60_000L), app.tls.fingerprint, app.identity.name(s.deviceName)).encode()
                qr = withContext(Dispatchers.Default) { Qr.bitmap(payload, 512) }
            }
            delay(s.qrTtlMin * 60_000L)
        }
    }
    LaunchedEffect(port) { if (addr == null) addr = withContext(Dispatchers.IO) { app.discovery.localAddress() } }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(stringResource(R.string.receive), color = c.text, fontWeight = FontWeight.Bold, fontSize = 22.sp, modifier = Modifier.padding(vertical = 12.dp))
        Text(app.identity.name(s.deviceName), color = c.accent, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))
        StatusChip(stringResource(if (port > 0) R.string.waiting_files else R.string.st_connecting), port > 0)
        Spacer(Modifier.height(16.dp))
        if (addr != null && port > 0) Text(stringResource(R.string.your_address, "$addr:$port"), color = c.text2, fontSize = 13.sp)
        Spacer(Modifier.height(12.dp))
        AeroButton(stringResource(if (showQr) R.string.hide_qr else R.string.show_qr), primary = false) { showQr = !showQr }
        if (showQr) { Spacer(Modifier.height(16.dp)); qr?.let { Box(Modifier.background(Color.White).padding(12.dp)) { Image(it.asImageBitmap(), null, Modifier.size(240.dp)) } } }
        Spacer(Modifier.height(20.dp))
        Text(stringResource(R.string.receive_hint), color = c.text2, fontSize = 13.sp, textAlign = TextAlign.Center)
        Text(stringResource(R.string.hotspot_hint), color = c.text2, fontSize = 12.sp, textAlign = TextAlign.Center)
        Text(stringResource(R.string.dest_label, app.store.destLabel(s.receiveTreeUri)), color = c.text2, fontSize = 12.sp)
    }
    incoming?.let { r ->
        AeroDialog(stringResource(R.string.incoming_title), body = {
            Text(stringResource(R.string.incoming_body, r.peerName, r.files.size, Formats.bytes(r.total)))
            Text(r.peerModel + " · " + stringResource(R.string.local_tls), fontSize = 13.sp)
            Text(stringResource(R.string.dest_label, app.store.destLabel(s.receiveTreeUri)), fontSize = 12.sp)
            if (r.storageWarn) Text(stringResource(R.string.storage_warn, Formats.bytes(app.store.free())), color = c.danger, fontSize = 13.sp)
        }, confirm = stringResource(R.string.accept), onConfirm = { app.engine.acceptIncoming(true) },
            dismiss = stringResource(R.string.decline), onDismiss = { app.engine.acceptIncoming(false) })
    }
}
