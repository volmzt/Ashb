package com.aero.share

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aero.share.ui.AeroNav
import com.aero.share.ui.AeroTheme

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val app = application as AeroApp
        setContent {
            val s by app.settings.flow.collectAsStateWithLifecycle(initialValue = app.settingsNow)
            AeroTheme(s) { AeroNav(app) }
        }
    }
}
