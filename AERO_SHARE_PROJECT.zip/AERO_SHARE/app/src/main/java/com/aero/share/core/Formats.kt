package com.aero.share.core

import java.util.Locale

object Formats {
    fun bytes(v: Long): String {
        if (v < 1024) return "$v B"
        val units = arrayOf("KB", "MB", "GB", "TB")
        var d = v.toDouble() / 1024.0
        var i = 0
        while (d >= 1024 && i < units.lastIndex) { d /= 1024.0; i++ }
        return String.format(Locale.US, "%.1f %s", d, units[i])
    }
    fun speed(bps: Long): String = bytes(bps) + "/s"
    fun duration(ms: Long): String {
        val s = ms / 1000
        val h = s / 3600; val m = (s % 3600) / 60; val sec = s % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
    }
    fun fpShort(fpHex: String): String = fpHex.take(16).uppercase().chunked(2).joinToString(":")
}
