package com.aero.share.storage

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import com.aero.share.core.Hash
import com.aero.share.core.PathGuard
import org.json.JSONObject
import java.io.File

data class AppEntry(
    val pkg: String, val label: String, val version: String,
    val size: Long, val icon: Drawable?, val base: File, val splits: List<File>
)
data class ApkInfo(val label: String, val pkg: String, val version: String, val sha256: String, val signer: String?)

object Apks {
    @Suppress("DEPRECATION")
    fun list(ctx: Context): List<AppEntry> {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val seen = HashSet<String>()
        val out = ArrayList<AppEntry>()
        for (ri in pm.queryIntentActivities(intent, 0)) {
            val ai = ri.activityInfo?.applicationInfo ?: continue
            if (!seen.add(ai.packageName)) continue
            runCatching {
                val base = File(ai.sourceDir)
                val splits = ai.splitSourceDirs?.map { File(it) } ?: emptyList()
                val pi = pm.getPackageInfo(ai.packageName, 0)
                out.add(AppEntry(ai.packageName, ai.loadLabel(pm).toString(), pi.versionName ?: "",
                    base.length() + splits.sumOf { it.length() }, ai.loadIcon(pm), base, splits))
            }
        }
        return out.sortedBy { it.label.lowercase() }
    }

    fun appFiles(ctx: Context, e: AppEntry): List<OutFile> {
        val dir = PathGuard.sanitizeRelative("${e.label}_${e.version}") ?: e.pkg
        val files = ArrayList<OutFile>()
        files.add(OutFile("$dir/base.apk", e.base.length(), file = e.base))
        e.splits.forEachIndexed { i, f -> files.add(OutFile("$dir/split_$i.apk", f.length(), file = f)) }
        val meta = JSONObject().put("package", e.pkg).put("label", e.label)
            .put("version", e.version).put("splits", e.splits.size).put("format", "aero-apk-v1").toString()
        val tmp = File(ctx.cacheDir, "apk_meta_${e.pkg}.json")
        tmp.writeText(meta)
        files.add(OutFile("$dir/aero-app.json", tmp.length(), file = tmp))
        return files
    }

    @Suppress("DEPRECATION")
    fun archiveInfo(ctx: Context, uri: Uri): ApkInfo? = runCatching {
        val tmp = File(ctx.cacheDir, "inspect.apk")
        ctx.contentResolver.openInputStream(uri)!!.use { i -> tmp.outputStream().use { o -> i.copyTo(o, 256 * 1024) } }
        val pm = ctx.packageManager
        val flags = if (Build.VERSION.SDK_INT >= 28) PackageManager.GET_SIGNING_CERTIFICATES else PackageManager.GET_SIGNATURES
        val pi = pm.getPackageArchiveInfo(tmp.absolutePath, flags)
        val sha = tmp.inputStream().use { Hash.stream(it, ByteArray(256 * 1024)) }
        val signer = if (Build.VERSION.SDK_INT >= 28)
            pi?.signingInfo?.apkContentsSigners?.firstOrNull()?.toByteArray()?.let { Hash.sha256Hex(it) }
        else pi?.signatures?.firstOrNull()?.toByteArray()?.let { Hash.sha256Hex(it) }
        val label = pi?.applicationInfo?.loadLabel(pm)?.toString() ?: tmp.name
        tmp.delete()
        ApkInfo(label, pi?.packageName ?: "?", pi?.versionName ?: "?", sha, signer)
    }.getOrNull()
}
