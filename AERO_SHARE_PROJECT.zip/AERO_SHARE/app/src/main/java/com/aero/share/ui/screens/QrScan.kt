package com.aero.share.ui.screens

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.navigation.NavController
import com.aero.share.AeroApp
import com.aero.share.R
import com.aero.share.ui.AeroButton
import com.aero.share.ui.aero
import com.google.zxing.BinaryBitmap
import com.google.zxing.DecodeHintType
import com.google.zxing.PlanarYUVLuminanceSource
import com.google.zxing.common.HybridBinarizer
import com.google.zxing.qrcode.QRCodeReader
import java.util.concurrent.Executors

@Composable
fun QrScan(app: AeroApp, nav: NavController) {
    val c = aero(); val ctx = LocalContext.current; val owner = LocalLifecycleOwner.current
    var granted by remember { mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == android.content.pm.PackageManager.PERMISSION_GRANTED) }
    var denied by remember { mutableStateOf(false) }
    var handled by remember { mutableStateOf(false) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it; denied = !it }
    LaunchedEffect(Unit) { if (!granted) launcher.launch(Manifest.permission.CAMERA) }
    Box(Modifier.fillMaxSize()) {
        if (granted) {
            AndroidView(factory = { context ->
                val pv = PreviewView(context)
                val f = ProcessCameraProvider.getInstance(context)
                f.addListener({
                    val provider = f.get()
                    val preview = Preview.Builder().build().also { it.surfaceProvider = pv.surfaceProvider }
                    val analysis = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
                    val reader = QRCodeReader()
                    val hints = mapOf(DecodeHintType.TRY_HARDER to true)
                    analysis.setAnalyzer(Executors.newSingleThreadExecutor()) { proxy ->
                        try {
                            val plane = proxy.planes[0]; val w = proxy.width; val h = proxy.height
                            val buf = plane.buffer; val rows = ByteArray(w * h); val stride = plane.rowStride
                            if (stride == w) buf.get(rows, 0, minOf(buf.remaining(), rows.size))
                            else { val row = ByteArray(stride); for (y in 0 until h) { buf.position(y * stride); buf.get(row, 0, minOf(stride, buf.remaining())); System.arraycopy(row, 0, rows, y * w, w) } }
                            val res = runCatching { reader.decode(BinaryBitmap(HybridBinarizer(PlanarYUVLuminanceSource(rows, w, h, 0, 0, w, h, false))), hints) }.getOrNull()
                            if (res != null && !handled) { handled = true; pv.post { app.scannedQr = res.text; nav.popBackStack() } }
                        } finally { proxy.close() }
                    }
                    runCatching { provider.unbindAll(); provider.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis) }
                }, ContextCompat.getMainExecutor(context))
                pv
            }, modifier = Modifier.fillMaxSize(), onRelease = { runCatching { ProcessCameraProvider.getInstance(ctx).get().unbindAll() } })
            Column(Modifier.align(Alignment.BottomCenter).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(stringResource(R.string.scanning_hint), color = Color.White)
                Spacer(Modifier.height(12.dp))
                AeroButton(stringResource(R.string.cancel), primary = false) { nav.popBackStack() }
            }
        } else if (denied) Column(Modifier.align(Alignment.Center).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(stringResource(R.string.camera_denied), color = c.text2)
            Spacer(Modifier.height(12.dp))
            AeroButton(stringResource(R.string.close)) { nav.popBackStack() }
        }
    }
}
