package com.aero.share.net

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import com.aero.share.core.Identity
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.net.NetworkInterface
import java.util.Base64

/** Real mDNS/DNS-SD discovery via NsdManager. No simulated devices. */
class Discovery(private val ctx: Context, private val identity: Identity, private val scope: CoroutineScope) {
    companion object { const val TYPE = "_aeroshare._tcp." }
    data class Found(val id: String, val name: String, val host: String, val port: Int, val service: String = "")
    enum class Status { IDLE, SEARCHING, NO_WIFI, HIDDEN, ERROR }

    private val nsd = ctx.getSystemService(Context.NSD_SERVICE) as NsdManager
    private val wifi = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
    private var lock: WifiManager.MulticastLock? = null
    private val _devices = MutableStateFlow<List<Found>>(emptyList()); val devices = _devices.asStateFlow()
    private val _status = MutableStateFlow(Status.IDLE); val status = _status.asStateFlow()
    private var reg: NsdManager.RegistrationListener? = null
    private var disc: NsdManager.DiscoveryListener? = null
    private val resolveQueue = ArrayDeque<NsdServiceInfo>()
    @Volatile private var resolving = false
    private var ownName = ""
    private var stopJob: Job? = null

    fun hasLocalNetwork(): Boolean {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        if (caps != null && (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET))) return true
        return runCatching {
            NetworkInterface.getNetworkInterfaces().toList().any {
                it.isUp && !it.isLoopback && (it.name.startsWith("ap") || it.name.startsWith("wlan") || it.name.startsWith("swlan")) &&
                    it.inetAddresses.toList().any { a -> a.isSiteLocalAddress }
            }
        }.getOrDefault(false)
    }

    fun localAddress(): String? = runCatching {
        NetworkInterface.getNetworkInterfaces().toList()
            .filter { it.isUp && !it.isLoopback }
            .flatMap { it.inetAddresses.toList() }
            .firstOrNull { it.isSiteLocalAddress && it.hostAddress?.contains('.') == true }?.hostAddress
    }.getOrNull()

    fun start(port: Int, deviceName: String, visible: Boolean, savingMode: Boolean) {
        stop()
        if (!visible) { _status.value = Status.HIDDEN; return }
        if (!hasLocalNetwork()) { _status.value = Status.NO_WIFI; return }
        if (port <= 0) { _status.value = Status.ERROR; return }
        lock = wifi.createMulticastLock("aero_discovery").apply { setReferenceCounted(false); acquire() }
        ownName = "AERO-" + identity.id.take(8)
        val info = NsdServiceInfo().apply {
            serviceName = ownName; serviceType = TYPE; setPort(port)
            setAttribute("id", identity.id)
            setAttribute("n", Base64.getEncoder().withoutPadding().encodeToString(deviceName.toByteArray(Charsets.UTF_8)))
        }
        reg = object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(i: NsdServiceInfo) { ownName = i.serviceName }
            override fun onRegistrationFailed(i: NsdServiceInfo, e: Int) { _status.value = Status.ERROR }
            override fun onServiceUnregistered(i: NsdServiceInfo) {}
            override fun onUnregistrationFailed(i: NsdServiceInfo, e: Int) {}
        }
        runCatching { nsd.registerService(info, NsdManager.PROTOCOL_DNS_SD, reg) }.onFailure { _status.value = Status.ERROR }
        disc = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(t: String) { _status.value = Status.SEARCHING }
            override fun onStartDiscoveryFailed(t: String, e: Int) { _status.value = Status.ERROR }
            override fun onDiscoveryStopped(t: String) {}
            override fun onStopDiscoveryFailed(t: String, e: Int) {}
            override fun onServiceLost(i: NsdServiceInfo) { _devices.update { l -> l.filterNot { it.service == i.serviceName } } }
            override fun onServiceFound(i: NsdServiceInfo) {
                if (i.serviceType.trimEnd('.') != TYPE.trimEnd('.') || i.serviceName == ownName) return
                synchronized(resolveQueue) { resolveQueue.addLast(i); resolveNext() }
            }
        }
        runCatching { nsd.discoverServices(TYPE, NsdManager.PROTOCOL_DNS_SD, disc) }.onFailure { _status.value = Status.ERROR }
        if (savingMode) stopJob = scope.launch { delay(30_000); stop() }
    }

    @Suppress("DEPRECATION")
    private fun resolveNext() {
        if (resolving) return
        val next = synchronized(resolveQueue) { resolveQueue.removeFirstOrNull() } ?: return
        resolving = true
        runCatching {
            nsd.resolveService(next, object : NsdManager.ResolveListener {
                override fun onResolveFailed(i: NsdServiceInfo, e: Int) {
                    resolving = false; synchronized(resolveQueue) { resolveNext() }
                }
                override fun onServiceResolved(i: NsdServiceInfo) {
                    runCatching {
                        val attrs = i.attributes
                        val id = attrs["id"]?.toString(Charsets.UTF_8) ?: ""
                        val name = attrs["n"]?.let { String(Base64.getDecoder().decode(it), Charsets.UTF_8) } ?: i.serviceName
                        val host = i.host?.hostAddress
                        if (id.isNotEmpty() && id != identity.id && host != null) {
                            val f = Found(id, name, host, i.port, i.serviceName)
                            _devices.update { l -> l.filterNot { it.id == id } + f }
                        }
                    }
                    resolving = false; synchronized(resolveQueue) { resolveNext() }
                }
            })
        }.onFailure { resolving = false }
    }

    fun stop() {
        stopJob?.cancel(); stopJob = null
        runCatching { disc?.let { nsd.stopServiceDiscovery(it) } }; disc = null
        runCatching { reg?.let { nsd.unregisterService(it) } }; reg = null
        runCatching { lock?.release() }; lock = null
        synchronized(resolveQueue) { resolveQueue.clear() }
        resolving = false
        _devices.value = emptyList()
        _status.value = Status.IDLE
    }
}
