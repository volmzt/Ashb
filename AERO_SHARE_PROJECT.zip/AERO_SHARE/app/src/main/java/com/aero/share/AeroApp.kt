package com.aero.share

import android.app.Application
import com.aero.share.core.Identity
import com.aero.share.data.*
import com.aero.share.net.DeviceTls
import com.aero.share.net.Discovery
import com.aero.share.net.Target
import com.aero.share.net.TransferEngine
import com.aero.share.service.TransferService
import com.aero.share.storage.OutFile
import com.aero.share.storage.ReceiverStore
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

class AeroApp : Application() {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    lateinit var settings: SettingsStore
    lateinit var identity: Identity
    lateinit var tls: DeviceTls
    lateinit var devices: DeviceRepo
    lateinit var history: HistoryRepo
    lateinit var store: ReceiverStore
    lateinit var engine: TransferEngine
    lateinit var discovery: Discovery
    var settingsNow = AppSettings()
    var pendingFiles: List<OutFile> = emptyList()
    var pendingTotal: Long = 0L
    var pendingTarget: Target? = null
    var scannedQr: String? = null

    override fun onCreate() {
        super.onCreate()
        settings = SettingsStore(this)
        identity = Identity(this)
        tls = DeviceTls(this)
        val db = AeroDb.build(this)
        devices = DeviceRepo(db.devices())
        history = HistoryRepo(db.history())
        store = ReceiverStore(this)
        engine = TransferEngine(this, tls, identity, store, devices, history, settings, scope)
        discovery = Discovery(this, identity, scope)
        TransferService.createChannels(this)
        runBlocking { runCatching { settingsNow = settings.flow.first() } }
        scope.launch { settings.flow.collect { settingsNow = it } }
        scope.launch(Dispatchers.IO) { runCatching { tls.certificate } }
    }
}
