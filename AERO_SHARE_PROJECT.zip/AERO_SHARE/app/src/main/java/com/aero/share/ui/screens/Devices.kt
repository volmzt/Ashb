package com.aero.share.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.aero.share.AeroApp
import com.aero.share.R
import com.aero.share.core.Formats
import com.aero.share.data.DeviceEntity
import com.aero.share.net.Target
import com.aero.share.ui.*
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date

@Composable
fun Devices(app: AeroApp, nav: NavController) {
    val c = aero(); val scope = rememberCoroutineScope()
    val known by app.devices.all.collectAsStateWithLifecycle(initialValue = emptyList())
    val found by app.discovery.devices.collectAsStateWithLifecycle()
    var sel by remember { mutableStateOf<DeviceEntity?>(null) }
    var alias by remember { mutableStateOf("") }
    val df = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        item { Text(stringResource(R.string.known_devices), color = c.text, fontWeight = FontWeight.Bold, fontSize = 22.sp, modifier = Modifier.padding(vertical = 16.dp)) }
        if (known.isEmpty()) item { EmptyState(R.drawable.ic_devices, stringResource(R.string.no_devices), stringResource(R.string.empty_devices)) }
        items(known, key = { it.fp }) { d ->
            val online = found.any { it.id == d.id }
            AeroCard(Modifier.fillMaxWidth().padding(vertical = 4.dp).then(AeroClick { sel = d; alias = d.alias })) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(painterResource(R.drawable.ic_device), null, tint = if (online) c.accent else c.text2, modifier = Modifier.size(26.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(d.display(), color = c.text, fontWeight = FontWeight.SemiBold)
                        Text(d.model + (if (d.trusted) " · " + stringResource(R.string.trusted) else "") + (if (d.blocked) " · " + stringResource(R.string.blocked) else ""), color = c.text2, fontSize = 12.sp)
                    }
                    StatusChip(stringResource(if (online) R.string.active else R.string.inactive), online)
                }
            }
        }
    }
    sel?.let { d ->
        val online = found.find { it.id == d.id }
        AeroDialog(d.display(), body = {
            Text("${stringResource(R.string.model)}: ${d.model}")
            Text("${stringResource(R.string.first_seen)}: ${df.format(Date(d.firstSeen))}")
            Text("${stringResource(R.string.last_seen)}: ${df.format(Date(d.lastSeen))}")
            Text(Formats.fpShort(d.fp), fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(alias, { alias = it }, label = { Text(stringResource(R.string.rename)) }, singleLine = true)
            SwitchRow(stringResource(R.string.trust_device), d.trusted) { v -> scope.launch { app.devices.upsert(d.copy(trusted = v)) }; sel = d.copy(trusted = v) }
            SwitchRow(stringResource(R.string.block), d.blocked) { v -> scope.launch { app.devices.upsert(d.copy(blocked = v)) }; sel = d.copy(blocked = v) }
            Row {
                AeroButton(stringResource(R.string.remove), primary = false) { scope.launch { app.devices.delete(d.fp) }; sel = null }
                if (online != null) {
                    Spacer(Modifier.width(8.dp))
                    AeroButton(stringResource(R.string.send)) { app.pendingTarget = Target(online.host, online.port, null, null, d.display()); sel = null; nav.navigate("send") }
                }
            }
        }, confirm = stringResource(R.string.ok), onConfirm = { scope.launch { app.devices.upsert(d.copy(alias = alias.trim())) }; sel = null },
            dismiss = stringResource(R.string.close), onDismiss = { sel = null })
    }
}
