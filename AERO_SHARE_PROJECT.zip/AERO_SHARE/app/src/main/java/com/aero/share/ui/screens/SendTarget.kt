package com.aero.share.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.aero.share.AeroApp
import com.aero.share.R
import com.aero.share.core.Formats
import com.aero.share.net.QrPayload
import com.aero.share.net.Target
import com.aero.share.ui.*

@Composable
fun SendTarget(app: AeroApp, nav: NavController) {
    val c = aero()
    val found by app.discovery.devices.collectAsStateWithLifecycle()
    val known by app.devices.all.collectAsStateWithLifecycle(initialValue = emptyList())
    val s by app.settings.flow.collectAsStateWithLifecycle(initialValue = app.settingsNow)
    var manual by remember { mutableStateOf(false) }
    var addr by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf<Target?>(null) }
    LaunchedEffect(Unit) {
        app.scannedQr?.let { raw -> app.scannedQr = null; QrPayload.decode(raw)?.let { confirm = Target(it.host, it.port, it.fp, it.token, it.name) } }
        app.pendingTarget?.let { confirm = it; app.pendingTarget = null }
    }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text(stringResource(R.string.choose_recipient), color = c.text, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Text(stringResource(R.string.selected_summary, app.pendingFiles.size, Formats.bytes(app.pendingTotal)), color = c.text2, fontSize = 13.sp)
        Spacer(Modifier.height(12.dp))
        Row {
            AeroButton(stringResource(R.string.scan_qr), Modifier.weight(1f)) { nav.navigate("scan") }
            Spacer(Modifier.width(8.dp))
            AeroButton(stringResource(R.string.manual_connect), Modifier.weight(1f), primary = false) { manual = true }
        }
        Spacer(Modifier.height(12.dp))
        if (app.pendingFiles.isEmpty()) EmptyState(R.drawable.ic_file, stringResource(R.string.empty_category), "") {
            AeroButton(stringResource(R.string.close), primary = false) { nav.popBackStack() }
        } else LazyColumn(Modifier.weight(1f)) {
            items(found, key = { it.id }) { d ->
                val k = known.find { it.id == d.id }
                AeroCard(Modifier.fillMaxWidth().padding(vertical = 4.dp).then(AeroClick { confirm = Target(d.host, d.port, null, null, k?.display() ?: d.name) })) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(painterResource(R.drawable.ic_device), null, tint = c.accent, modifier = Modifier.size(24.dp))
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(k?.display() ?: d.name, color = c.text, fontWeight = FontWeight.SemiBold)
                            Text(stringResource(R.string.local_tls), color = c.text2, fontSize = 12.sp)
                        }
                        if (k?.trusted == true) Icon(painterResource(R.drawable.ic_shield), null, tint = c.accent, modifier = Modifier.size(16.dp))
                    }
                }
            }
            if (found.isEmpty()) item { EmptyState(R.drawable.ic_devices, stringResource(R.string.no_devices), stringResource(R.string.no_devices_hint)) }
        }
    }
    if (manual) AeroDialog(stringResource(R.string.manual_connect), body = {
        OutlinedTextField(addr, { addr = it }, label = { Text(stringResource(R.string.ip_port)) }, singleLine = true)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(code, { code = it }, label = { Text(stringResource(R.string.pairing_code_optional)) }, singleLine = true)
    }, confirm = stringResource(R.string.connect), onConfirm = {
        manual = false
        val hp = addr.trim().split(":"); val port = hp.getOrNull(1)?.toIntOrNull()
        if (hp[0].isNotBlank() && port != null) confirm = Target(hp[0], port, null, code.trim().ifBlank { null }, hp[0])
    }, dismiss = stringResource(R.string.cancel), onDismiss = { manual = false })
    confirm?.let { t ->
        AeroDialog(stringResource(R.string.send), body = {
            Text(stringResource(R.string.confirm_send, app.pendingFiles.size, Formats.bytes(app.pendingTotal), t.label))
            Text(stringResource(R.string.local_tls), color = c.accent, fontSize = 13.sp)
            if (app.pendingTotal > (1L shl 30) && s.warnLarge) Text(stringResource(R.string.confirm_send_large), fontSize = 13.sp)
        }, confirm = stringResource(R.string.send), onConfirm = {
            confirm = null
            app.engine.enqueueSend(t, app.pendingFiles)
            app.pendingFiles = emptyList(); app.pendingTotal = 0
            nav.navigate("transfer") { popUpTo("home") }
        }, dismiss = stringResource(R.string.cancel), onDismiss = { confirm = null })
    }
}
