package com.aero.share.ui.screens

import android.app.DownloadManager
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.aero.share.AeroApp
import com.aero.share.R
import com.aero.share.core.Formats
import com.aero.share.ui.*
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date

@Composable
fun History(app: AeroApp, nav: NavController) {
    val c = aero(); val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    val all by app.history.all.collectAsStateWithLifecycle(initialValue = emptyList())
    var filter by remember { mutableStateOf("all") }
    val filters = listOf("all" to R.string.filter_all, "Send" to R.string.filter_sent, "Receive" to R.string.filter_received,
        "Completed" to R.string.filter_completed, "Failed" to R.string.filter_failed, "Cancelled" to R.string.filter_cancelled)
    val shown = all.filter { when (filter) { "all" -> true; "Send", "Receive" -> it.direction == filter; "Failed" -> it.status == "Failed" || it.status == "Interrupted"; else -> it.status == filter } }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(stringResource(R.string.history), color = c.text, fontWeight = FontWeight.Bold, fontSize = 22.sp, modifier = Modifier.weight(1f))
            if (all.isNotEmpty()) AeroButton(stringResource(R.string.clear_history), primary = false) { scope.launch { app.history.clear() } }
        }
        Spacer(Modifier.height(8.dp))
        LazyRow { items(filters) { (k, label) ->
            val s = filter == k
            Box(Modifier.padding(end = 6.dp).clip(RoundedCornerShape(10.dp)).background(if (s) c.accent else c.surface2)
                .then(AeroClick { filter = k }).padding(horizontal = 12.dp, vertical = 7.dp)) {
                Text(stringResource(label), color = if (s) Color.Black else c.text2, fontSize = 12.sp)
            }
        } }
        Spacer(Modifier.height(8.dp))
        if (shown.isEmpty()) EmptyState(R.drawable.ic_history, stringResource(R.string.empty_history), "")
        LazyColumn {
            items(shown, key = { it.id }) { h ->
                AeroCard(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(painterResource(if (h.direction == "Send") R.drawable.ic_logo else R.drawable.ic_receive), null,
                            tint = if (h.status == "Completed") c.accent else c.text2, modifier = Modifier.size(24.dp))
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(h.peer, color = c.text, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                            Text("${stringResource(R.string.files_label, h.files)} · ${Formats.bytes(h.bytes)} · ${Formats.duration(h.durationMs)}", color = c.text2, fontSize = 12.sp)
                            Text(DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(h.ts)), color = c.text2, fontSize = 11.sp)
                        }
                        val st = when (h.status) { "Completed" -> R.string.st_completed; "Failed" -> R.string.st_failed; "Cancelled" -> R.string.st_cancelled; "Interrupted" -> R.string.st_interrupted; "Paused" -> R.string.st_paused; else -> R.string.st_waiting }
                        Text(stringResource(st), color = if (h.status == "Completed") c.success else c.text2, fontSize = 11.sp)
                    }
                }
            }
            if (shown.any { it.direction == "Receive" && it.status == "Completed" }) item {
                Spacer(Modifier.height(8.dp))
                AeroButton(stringResource(R.string.open_folder), primary = false) { runCatching { ctx.startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)) } }
            }
        }
    }
}
