package com.aero.share.net

import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.IOException

/**
 * AERO wire protocol v1. TLS mutual auth, then length-prefixed JSON control frames
 * (4-byte big-endian length + UTF-8). File bytes stream raw between FILE and END.
 * One Msg type carries every control message; `type` discriminates.
 */
object Proto {
    const val VERSION = 1
    const val MAX_FRAME = 4 shl 20
    val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    inline fun <reified T> write(out: DataOutputStream, msg: T) {
        val b = json.encodeToString(msg).toByteArray(Charsets.UTF_8)
        if (b.size > MAX_FRAME) throw IOException("Frame too large")
        out.writeInt(b.size); out.write(b); out.flush()
    }
    inline fun <reified T> read(inp: DataInputStream): T {
        val n = inp.readInt()
        if (n <= 0 || n > MAX_FRAME) throw IOException("Bad frame size: $n")
        val b = ByteArray(n); inp.readFully(b)
        return json.decodeFromString(String(b, Charsets.UTF_8))
    }
}

@Serializable data class FileMeta(val id: String, val path: String, val size: Long)

@Serializable data class Msg(
    val type: String,
    val v: Int = 1,
    val id: String? = null,
    val name: String? = null,
    val model: String? = null,
    val token: String? = null,
    val transferId: String? = null,
    val files: List<FileMeta>? = null,
    val resumeDone: List<String>? = null,
    val ok: Boolean? = null,
    val reason: String? = null,
    val sha256: String? = null,
    val skipped: Boolean? = null
)
