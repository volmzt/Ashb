package com.aero.share.ui.screens

import android.Manifest
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.aero.share.AeroApp
import com.aero.share.BuildConfig
import com.aero.share.R
import com.aero.share.ui.*
import java.text.DateFormat
import java.util.Date

@Composable
fun Diagnostics(app: AeroApp, nav: NavController) {
    val c = aero(); val ctx = LocalContext.current
    val errors by app.engine.errors.collectAsStateWithLifecycle()
    val serverOn by app.engine.serverOn.collectAsStateWithLifecycle()
    val status by app.discovery.status.collectAsStateWithLifecycle()
    val wd = ctx.packageManager.hasSystemFeature(PackageManager.FEATURE_WIFI_DIRECT)
    val bt = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter != null
    fun report() = buildString {
        appendLine("AERO SHARE diagnostics")
        appendLine("App: ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})")
        appendLine("Android: ${Build.VERSION.RELEASE} API ${Build.VERSION.SDK_INT}")
        appendLine("Model: ${Build.MODEL}")
        appendLine("WiFiDirect HW: $wd (unused v1); BT HW: $bt (unused v1)")
        appendLine("Discovery: $status; server: $serverOn")
        appendLine("Errors: " + errors.joinToString { it.code })
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text(stringResource(R.string.sec_diagnostics), color = c.text, fontWeight = FontWeight.Bold, fontSize = 22.sp, modifier = Modifier.padding(vertical = 12.dp))
        AeroCard(Modifier.fillMaxWidth()) {
            DRow(stringResource(R.string.app_version), "${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})")
            DRow(stringResource(R.string.android_version), "${Build.VERSION.RELEASE} · API ${Build.VERSION.SDK_INT}")
            DRow(stringResource(R.string.model), Build.MODEL)
        }
        SectionTitle(stringResource(R.string.capabilities))
        AeroCard(Modifier.fillMaxWidth()) {
            DRow("Wi-Fi / mDNS", stringResource(R.string.active))
            DRow(stringResource(R.string.wifi_direct_hw), stringResource(if (wd) R.string.hw_yes_not_used else R.string.hw_no))
            DRow(stringResource(R.string.bt_hw), stringResource(if (bt) R.string.hw_yes_not_used else R.string.hw_no))
            DRow(stringResource(R.string.discovery_status), status.name)
            DRow(stringResource(R.string.server_status), stringResource(if (serverOn) R.string.active else R.string.inactive))
        }
        SectionTitle(stringResource(R.string.permissions_status))
        AeroCard(Modifier.fillMaxWidth()) {
            val perms = if (Build.VERSION.SDK_INT >= 33) listOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.POST_NOTIFICATIONS, Manifest.permission.CAMERA)
            else listOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.CAMERA)
            perms.forEach { p -> DRow(p.substringAfterLast('.'), stringResource(if (ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED) R.string.granted else R.string.not_granted)) }
        }
        SectionTitle(stringResource(R.string.recent_errors))
        AeroCard(Modifier.fillMaxWidth()) {
            if (errors.isEmpty()) Text(stringResource(R.string.no_errors), color = c.text2, fontSize = 13.sp)
            errors.forEach { Text("${DateFormat.getTimeInstance(DateFormat.MEDIUM).format(Date(it.time))} · ${it.code}", color = c.text2, fontSize = 12.sp) }
        }
        Spacer(Modifier.height(12.dp))
        AeroButton(stringResource(R.string.diag_export), Modifier.fillMaxWidth()) {
            runCatching { ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, report()) }, null)) }
        }
        Spacer(Modifier.height(8.dp))
        AeroButton(stringResource(R.string.close), Modifier.fillMaxWidth(), primary = false) { nav.popBackStack() }
    }
}

@Composable private fun DRow(k: String, v: String) {
    val c = aero()
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(k, color = c.text2, fontSize = 13.sp, modifier = Modifier.weight(1f)); Text(v, color = c.text, fontSize = 13.sp)
    }
}
