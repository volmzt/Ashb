package com.aero.share.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.os.LocaleListCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.aero.share.AeroApp
import com.aero.share.BuildConfig
import com.aero.share.R
import com.aero.share.data.ConflictMode
import com.aero.share.data.PowerMode
import com.aero.share.data.ThemeMode
import com.aero.share.ui.*
import kotlinx.coroutines.launch

private fun langLabel(t: String) = when (t) { "en" -> "English"; "uk" -> "Українська"; "ru" -> "Русский"; else -> "" }

@Composable
fun Settings(app: AeroApp, nav: NavController) {
    val c = aero(); val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    val s by app.settings.flow.collectAsStateWithLifecycle(initialValue = app.settingsNow)
    var dialog by remember { mutableStateOf<String?>(null) }
    var nameText by remember(s.deviceName) { mutableStateOf(s.deviceName) }
    val tree = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { u ->
        if (u != null) {
            runCatching { ctx.contentResolver.takePersistableUriPermission(u, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION) }
            scope.launch { app.settings.setTree(u.toString()) }
        }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text(stringResource(R.string.nav_settings), color = c.text, fontWeight = FontWeight.Bold, fontSize = 22.sp, modifier = Modifier.padding(vertical = 12.dp))
        SectionTitle(stringResource(R.string.sec_general))
        AeroCard(Modifier.fillMaxWidth()) {
            ClickRow(stringResource(R.string.language), if (s.language.isEmpty()) stringResource(R.string.lang_system) else langLabel(s.language)) { dialog = "lang" }
            ClickRow(stringResource(R.string.device_name), app.identity.name(s.deviceName)) { dialog = "name" }
            SwitchRow(stringResource(R.string.startup_discovery), s.startupDiscovery) { v -> scope.launch { app.settings.setStartupDiscovery(v) } }
            ClickRow(stringResource(R.string.receive_dir), app.store.destLabel(s.receiveTreeUri)) { tree.launch(null) }
            if (s.receiveTreeUri.isNotEmpty()) ClickRow(stringResource(R.string.reset), stringResource(R.string.default_dir)) { scope.launch { app.settings.setTree("") } }
            SwitchRow(stringResource(R.string.notifications), s.notifications) { v -> scope.launch { app.settings.setNotifications(v) } }
            SwitchRow(stringResource(R.string.progress_notif), s.progressNotif) { v -> scope.launch { app.settings.setProgressNotif(v) } }
        }
        SectionTitle(stringResource(R.string.sec_connections))
        AeroCard(Modifier.fillMaxWidth()) {
            SwitchRow(stringResource(R.string.visibility), s.visible, stringResource(R.string.visibility_hint)) { v -> scope.launch { app.settings.setVisible(v) } }
            ClickRow(stringResource(R.string.timeout), stringResource(R.string.seconds, s.timeoutSec)) { dialog = "timeout" }
            ClickRow(stringResource(R.string.qr_ttl), stringResource(R.string.minutes, s.qrTtlMin)) { dialog = "ttl" }
            Text(stringResource(R.string.roadmap_note), color = c.text2, fontSize = 12.sp)
        }
        SectionTitle(stringResource(R.string.sec_transfers))
        AeroCard(Modifier.fillMaxWidth()) {
            SwitchRow(stringResource(R.string.auto_accept_trusted), s.autoAcceptTrusted, stringResource(R.string.auto_accept_hint)) { v -> scope.launch { app.settings.setAutoAccept(v) } }
            ClickRow(stringResource(R.string.conflict), stringResource(if (s.conflict == ConflictMode.RENAME) R.string.conflict_rename else R.string.conflict_skip)) { dialog = "conflict" }
            SwitchRow(stringResource(R.string.warn_large), s.warnLarge) { v -> scope.launch { app.settings.setWarnLarge(v) } }
            SwitchRow(stringResource(R.string.cleanup_temp), s.cleanupTemp) { v -> scope.launch { app.settings.setCleanup(v) } }
        }
        SectionTitle(stringResource(R.string.sec_power))
        AeroCard(Modifier.fillMaxWidth()) {
            listOf(Triple(PowerMode.BALANCED, R.string.power_balanced, R.string.power_balanced_desc),
                Triple(PowerMode.PERFORMANCE, R.string.power_performance, R.string.power_performance_desc),
                Triple(PowerMode.SAVING, R.string.power_saving, R.string.power_saving_desc)).forEach { (m, l, d) ->
                Row(Modifier.fillMaxWidth().then(AeroClick { scope.launch { app.settings.setPower(m) } }).padding(vertical = 6.dp)) {
                    RadioButton(selected = s.power == m, onClick = { scope.launch { app.settings.setPower(m) } }, colors = RadioButtonDefaults.colors(selectedColor = c.accent))
                    Column { Text(stringResource(l), color = c.text, fontSize = 15.sp); Text(stringResource(d), color = c.text2, fontSize = 12.sp) }
                }
            }
        }
        SectionTitle(stringResource(R.string.sec_appearance))
        AeroCard(Modifier.fillMaxWidth()) {
            ClickRow(stringResource(R.string.theme), stringResource(when (s.theme) { ThemeMode.SYSTEM -> R.string.theme_system; ThemeMode.DARK -> R.string.theme_dark; ThemeMode.LIGHT -> R.string.theme_light })) { dialog = "theme" }
            ClickRow(stringResource(R.string.accent), stringResource(when (s.accent) { "amber" -> R.string.accent_amber; "coral" -> R.string.accent_coral; "mint" -> R.string.accent_mint; else -> R.string.accent_orange })) { dialog = "accent" }
            SwitchRow(stringResource(R.string.animations), s.animations) { v -> scope.launch { app.settings.setAnimations(v) } }
            SwitchRow(stringResource(R.string.haptics), s.haptics) { v -> scope.launch { app.settings.setHaptics(v) } }
            SwitchRow(stringResource(R.string.sound), s.sound) { v -> scope.launch { app.settings.setSound(v) } }
            SwitchRow(stringResource(R.string.glass), s.glass) { v -> scope.launch { app.settings.setGlass(v) } }
        }
        SectionTitle(stringResource(R.string.sec_security))
        AeroCard(Modifier.fillMaxWidth()) {
            Text(stringResource(R.string.security_info), color = c.text2, fontSize = 13.sp)
            ClickRow(stringResource(R.string.nav_devices), "") { nav.navigate("devices") }
        }
        SectionTitle(stringResource(R.string.sec_diagnostics))
        AeroCard(Modifier.fillMaxWidth().then(AeroClick { nav.navigate("diagnostics") })) { Text(stringResource(R.string.sec_diagnostics), color = c.text) }
        SectionTitle(stringResource(R.string.sec_about))
        AeroCard(Modifier.fillMaxWidth()) {
            Row {
                Icon(painterResource(R.drawable.ic_logo), null, tint = c.accent, modifier = Modifier.size(40.dp))
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(stringResource(R.string.app_name), color = c.text, fontWeight = FontWeight.Bold)
                    Text("${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})", color = c.text2, fontSize = 12.sp)
                    Text(stringResource(R.string.developer), color = c.text2, fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(stringResource(R.string.about_desc), color = c.text2, fontSize = 13.sp)
            Text(stringResource(R.string.privacy_note), color = c.text2, fontSize = 12.sp)
            Text(stringResource(R.string.licenses), color = c.text2, fontSize = 11.sp)
        }
        Spacer(Modifier.height(24.dp))
    }
    when (dialog) {
        "lang" -> AeroDialog(stringResource(R.string.language), body = {
            listOf("", "en", "uk", "ru").forEach { t ->
                ClickRow(if (t.isEmpty()) stringResource(R.string.lang_system) else langLabel(t), if (s.language == t) "✓" else null) {
                    scope.launch { app.settings.setLanguage(t) }
                    AppCompatDelegate.setApplicationLocales(if (t.isEmpty()) LocaleListCompat.getEmptyLocaleList() else LocaleListCompat.forLanguageTags(t))
                    dialog = null
                }
            }
        }, confirm = stringResource(R.string.close), onConfirm = { dialog = null })
        "name" -> AeroDialog(stringResource(R.string.device_name), body = { OutlinedTextField(nameText, { nameText = it }, singleLine = true, label = { Text(app.identity.model) }) },
            confirm = stringResource(R.string.ok), onConfirm = { scope.launch { app.settings.setDeviceName(nameText) }; dialog = null }, dismiss = stringResource(R.string.cancel), onDismiss = { dialog = null })
        "theme" -> AeroDialog(stringResource(R.string.theme), body = {
            listOf(ThemeMode.SYSTEM to R.string.theme_system, ThemeMode.DARK to R.string.theme_dark, ThemeMode.LIGHT to R.string.theme_light).forEach { (m, l) ->
                ClickRow(stringResource(l), if (s.theme == m) "✓" else null) { scope.launch { app.settings.setTheme(m) }; dialog = null } }
        }, confirm = stringResource(R.string.close), onConfirm = { dialog = null })
        "accent" -> AeroDialog(stringResource(R.string.accent), body = {
            listOf("orange" to R.string.accent_orange, "amber" to R.string.accent_amber, "coral" to R.string.accent_coral, "mint" to R.string.accent_mint).forEach { (k, l) ->
                ClickRow(stringResource(l), if (s.accent == k) "✓" else null) { scope.launch { app.settings.setAccent(k) }; dialog = null } }
        }, confirm = stringResource(R.string.close), onConfirm = { dialog = null })
        "timeout" -> AeroDialog(stringResource(R.string.timeout), body = {
            var v by remember { mutableStateOf(s.timeoutSec.toFloat()) }
            Slider(v, { v = it }, valueRange = 5f..30f, steps = 4, colors = SliderDefaults.colors(thumbColor = c.accent, activeTrackColor = c.accent))
            Text(stringResource(R.string.seconds, v.toInt()), color = c.text)
            AeroButton(stringResource(R.string.ok)) { scope.launch { app.settings.setTimeout(v.toInt()) }; dialog = null }
        }, confirm = stringResource(R.string.close), onConfirm = { dialog = null })
        "ttl" -> AeroDialog(stringResource(R.string.qr_ttl), body = {
            listOf(1, 5, 10).forEach { m -> ClickRow(stringResource(R.string.minutes, m), if (s.qrTtlMin == m) "✓" else null) { scope.launch { app.settings.setQrTtl(m) }; dialog = null } }
        }, confirm = stringResource(R.string.close), onConfirm = { dialog = null })
        "conflict" -> AeroDialog(stringResource(R.string.conflict), body = {
            listOf(ConflictMode.RENAME to R.string.conflict_rename, ConflictMode.SKIP to R.string.conflict_skip).forEach { (m, l) ->
                ClickRow(stringResource(l), if (s.conflict == m) "✓" else null) { scope.launch { app.settings.setConflict(m) }; dialog = null } }
        }, confirm = stringResource(R.string.close), onConfirm = { dialog = null })
    }
}
