package com.aero.share.storage

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import androidx.documentfile.provider.DocumentFile
import com.aero.share.core.PathGuard
import com.aero.share.data.ConflictMode
import java.io.File
import java.io.OutputStream

class ReceiverStore(private val ctx: Context) {
    class Dest(
        val uri: Uri, val out: OutputStream, val skipped: Boolean,
        private val fin: () -> Unit, private val ab: () -> Unit
    ) {
        fun finalize() = fin()
        fun abort() = ab()
    }

    fun free(): Long = StatFs(Environment.getDataDirectory().path).availableBytes

    fun mimeOf(name: String): String =
        MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substringAfterLast('.', "").lowercase())
            ?: "application/octet-stream"

    @Suppress("DEPRECATION")
    private fun existingNames(subDir: String, treeUri: String): Set<String> {
        val names = HashSet<String>()
        if (treeUri.isNotEmpty()) {
            var d = DocumentFile.fromTreeUri(ctx, Uri.parse(treeUri))
            for (p in subDir.split('/').filter { it.isNotEmpty() }) d = d?.findFile(p)
            d?.listFiles()?.forEach { it.name?.let(names::add) }
        } else if (Build.VERSION.SDK_INT >= 29) {
            val rel = Environment.DIRECTORY_DOWNLOADS + "/AERO SHARE/" + if (subDir.isEmpty()) "" else "$subDir/"
            ctx.contentResolver.query(
                MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                arrayOf(MediaStore.Downloads.DISPLAY_NAME),
                "${MediaStore.Downloads.RELATIVE_PATH} = ?", arrayOf(rel), null
            )?.use { c -> while (c.moveToNext()) names.add(c.getString(0)) }
        } else {
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "AERO SHARE/$subDir")
            dir.listFiles()?.forEach { names.add(it.name) }
        }
        return names
    }

    @Suppress("DEPRECATION")
    fun open(relPath: String, size: Long, treeUri: String, conflict: ConflictMode): Dest {
        val safe = PathGuard.sanitizeRelative(relPath) ?: throw SecurityException("Bad path")
        val subDir = safe.substringBeforeLast('/', "")
        val rawName = safe.substringAfterLast('/')
        val taken = existingNames(subDir, treeUri)
        if (conflict == ConflictMode.SKIP && rawName in taken) {
            return Dest(Uri.EMPTY, object : OutputStream() { override fun write(b: Int) {} }, true, {}, {})
        }
        val name = PathGuard.uniqueName(rawName, taken)
        val mime = mimeOf(name)
        if (treeUri.isNotEmpty()) {
            var d = DocumentFile.fromTreeUri(ctx, Uri.parse(treeUri))!!
            for (p in subDir.split('/').filter { it.isNotEmpty() })
                d = d.findFile(p)?.takeIf { it.isDirectory } ?: d.createDirectory(p)!!
            val doc = d.createFile(mime, name)!!
            val out = ctx.contentResolver.openOutputStream(doc.uri)!!
            return Dest(doc.uri, out, false, {}, { doc.delete() })
        }
        if (Build.VERSION.SDK_INT >= 29) {
            val rel = Environment.DIRECTORY_DOWNLOADS + "/AERO SHARE/" + if (subDir.isEmpty()) "" else "$subDir/"
            val cv = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, rel)
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)!!
            val out = ctx.contentResolver.openOutputStream(uri)!!
            return Dest(uri, out, false, {
                ctx.contentResolver.update(uri, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null)
            }, { ctx.contentResolver.delete(uri, null, null) })
        }
        val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "AERO SHARE/$subDir")
        dir.mkdirs()
        val part = File(dir, "$name.part")
        val fin = File(dir, name)
        return Dest(
            FileProvider.getUriForFile(ctx, ctx.packageName + ".files", fin),
            part.outputStream(), false, { part.renameTo(fin) }, { part.delete() }
        )
    }

    fun destLabel(treeUri: String): String =
        if (treeUri.isEmpty()) "Downloads/AERO SHARE"
        else DocumentFile.fromTreeUri(ctx, Uri.parse(treeUri))?.name ?: "Downloads/AERO SHARE"
}
