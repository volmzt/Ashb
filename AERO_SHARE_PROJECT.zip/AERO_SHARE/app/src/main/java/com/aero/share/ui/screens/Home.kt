package com.aero.share.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.aero.share.AeroApp
import com.aero.share.R
import com.aero.share.data.PowerMode
import com.aero.share.net.Dir
import com.aero.share.net.Discovery
import com.aero.share.net.Target
import com.aero.share.net.TState
import com.aero.share.ui.*

@Composable
fun Home(app: AeroApp, nav: NavController) {
    val c = aero()
    val settings by app.settings.flow.collectAsStateWithLifecycle(initialValue = app.settingsNow)
    val found by app.discovery.devices.collectAsStateWithLifecycle()
    val status by app.discovery.status.collectAsStateWithLifecycle()
    val known by app.devices.all.collectAsStateWithLifecycle(initialValue = emptyList())
    val active by app.engine.active.collectAsStateWithLifecycle()

    LaunchedEffect(active?.state) {
        if (active?.state == TState.Transferring && active?.dir == Dir.Send) nav.navigate("transfer") { launchSingleTop = true }
    }

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Row(Modifier.fillMaxWidth().padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(painterResource(R.drawable.ic_logo), null, tint = c.accent, modifier = Modifier.size(30.dp))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(stringResource(R.string.app_name), color = c.text, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text(app.identity.name(settings.deviceName), color = c.text2, fontSize = 12.sp)
                }
                Box(Modifier.then(AeroClick { nav.navigate("history") }).padding(8.dp)) {
                    Icon(painterResource(R.drawable.ic_history), stringResource(R.string.history), tint = c.text2, modifier = Modifier.size(22.dp))
                }
            }
            AeroCard(Modifier.fillMaxWidth().then(AeroClick { nav.navigate("send") })) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Send, null, tint = c.accent, modifier = Modifier.size(34.dp))
                    Spacer(Modifier.width(16.dp))
                    Column {
                        Text(stringResource(R.string.send), color = c.text, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                        Text(stringResource(R.string.send_desc), color = c.text2, fontSize = 13.sp)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            AeroCard(Modifier.fillMaxWidth().then(AeroClick { nav.navigate("receive") })) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(painterResource(R.drawable.ic_receive), null, tint = c.accent, modifier = Modifier.size(34.dp))
                    Spacer(Modifier.width(16.dp))
                    Column {
                        Text(stringResource(R.string.receive), color = c.text, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                        Text(stringResource(R.string.receive_desc), color = c.text2, fontSize = 13.sp)
                    }
                }
            }
            Spacer(Modifier.height(20.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                SectionTitle(stringResource(R.string.nearby_devices) + "  ·  ${found.size}", Modifier.weight(1f))
                Box(Modifier.then(AeroClick {
                    app.discovery.start(app.engine.serverPort.value, app.identity.name(settings.deviceName),
                        settings.visible, settings.power == PowerMode.SAVING)
                }).padding(8.dp)) {
                    Icon(Icons.Filled.Refresh, stringResource(R.string.refresh), tint = c.accent, modifier = Modifier.size(20.dp))
                }
            }
            when (status) {
                Discovery.Status.SEARCHING -> StatusChip(stringResource(if (found.isEmpty()) R.string.searching else R.string.nearby_devices), true)
                Discovery.Status.NO_WIFI -> StatusChip(stringResource(R.string.no_wifi), false)
                Discovery.Status.HIDDEN -> StatusChip(stringResource(R.string.hidden_mode), false)
                Discovery.Status.ERROR -> StatusChip(stringResource(R.string.err_network), false)
                Discovery.Status.IDLE -> StatusChip(stringResource(R.string.inactive), false)
            }
            Spacer(Modifier.height(8.dp))
        }
        if (found.isEmpty()) {
            item {
                val (t, b) = when (status) {
                    Discovery.Status.NO_WIFI -> R.string.no_wifi to R.string.no_wifi_hint
                    Discovery.Status.HIDDEN -> R.string.hidden_mode to R.string.hidden_hint
                    else -> R.string.no_devices to R.string.no_devices_hint
                }
                EmptyState(R.drawable.ic_devices, stringResource(t), stringResource(b)) {
                    AeroButton(stringResource(R.string.send), primary = false) { nav.navigate("send") }
                }
            }
        } else items(found, key = { it.id }) { d ->
            val k = known.find { it.id == d.id }
            AeroCard(Modifier.fillMaxWidth().padding(vertical = 4.dp).then(AeroClick {
                app.pendingTarget = Target(d.host, d.port, null, null, k?.display() ?: d.name)
                nav.navigate("send")
            })) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(painterResource(R.drawable.ic_device), null, tint = c.text2, modifier = Modifier.size(26.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(k?.display() ?: d.name, color = c.text, fontWeight = FontWeight.SemiBold)
                        Text(stringResource(R.string.android_device) + " · " + stringResource(R.string.local_tls), color = c.text2, fontSize = 12.sp)
                    }
                    if (k?.trusted == true) Icon(painterResource(R.drawable.ic_shield), stringResource(R.string.trusted), tint = c.accent, modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}
