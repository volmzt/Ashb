package com.aero.share.ui

import android.provider.Settings
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aero.share.AeroApp
import com.aero.share.data.AppSettings
import com.aero.share.data.ThemeMode

data class AeroColors(
    val bg: Color, val surface: Color, val surface2: Color, val elevated: Color,
    val accent: Color, val accent2: Color, val text: Color, val text2: Color,
    val divider: Color, val success: Color, val danger: Color, val glass: Boolean
)

val DarkAero = AeroColors(Color(0xFF090909), Color(0xFF141414), Color(0xFF1C1C1C), Color(0xFF222222),
    Color(0xFFFF7900), Color(0xFFFF9A35), Color.White, Color(0xFFA3A3A3), Color(0xFF303030),
    Color(0xFF3DDC97), Color(0xFFFF5A5A), false)
val LightAero = AeroColors(Color(0xFFF6F6F6), Color.White, Color(0xFFF0F0F0), Color.White,
    Color(0xFFFF7900), Color(0xFFFF9A35), Color(0xFF111111), Color(0xFF6B6B6B), Color(0xFFE2E2E2),
    Color(0xFF1FA97A), Color(0xFFD93636), false)

fun accents(key: String): Pair<Color, Color> = when (key) {
    "amber" -> Color(0xFFFFB300) to Color(0xFFFFCF66)
    "coral" -> Color(0xFFFF5A3C) to Color(0xFFFF8A70)
    "mint" -> Color(0xFF3DDC97) to Color(0xFF7FE8BC)
    else -> Color(0xFFFF7900) to Color(0xFFFF9A35)
}

val LocalAero = staticCompositionLocalOf { DarkAero }
val LocalMotion = compositionLocalOf { true }

private val AeroType = Typography(
    headlineMedium = TextStyle(fontSize = 26.sp, fontWeight = FontWeight.Bold),
    titleLarge = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.SemiBold),
    titleMedium = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.SemiBold),
    bodyLarge = TextStyle(fontSize = 16.sp), bodyMedium = TextStyle(fontSize = 14.sp),
    labelLarge = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.SemiBold),
    labelMedium = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.Medium)
)
private val AeroShapes = Shapes(small = RoundedCornerShape(10.dp), medium = RoundedCornerShape(14.dp), large = RoundedCornerShape(18.dp))

@Composable
fun AeroTheme(s: AppSettings, content: @Composable () -> Unit) {
    val dark = when (s.theme) { ThemeMode.DARK -> true; ThemeMode.LIGHT -> false; ThemeMode.SYSTEM -> isSystemInDarkTheme() }
    val (a, a2) = accents(s.accent)
    val colors = (if (dark) DarkAero else LightAero).copy(accent = a, accent2 = a2, glass = s.glass)
    val reduced = Settings.Global.getFloat(LocalContext.current.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
    val scheme = if (dark) darkColorScheme(primary = a, background = colors.bg, surface = colors.surface, onPrimary = Color.Black, onBackground = colors.text, onSurface = colors.text)
    else lightColorScheme(primary = a, background = colors.bg, surface = colors.surface, onPrimary = Color.Black, onBackground = colors.text, onSurface = colors.text)
    CompositionLocalProvider(LocalAero provides colors, LocalMotion provides (s.animations && !reduced)) {
        MaterialTheme(colorScheme = scheme, typography = AeroType, shapes = AeroShapes, content = content)
    }
}

@Composable fun aero(): AeroColors = LocalAero.current

@Composable
fun AeroClick(onClick: () -> Unit): Modifier {
    val h = LocalHapticFeedback.current
    val app = LocalContext.current.applicationContext as AeroApp
    return Modifier.clickable {
        if (app.settingsNow.haptics) h.performHapticFeedback(HapticFeedbackType.LongPress)
        onClick()
    }
}

@Composable
fun AeroCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val c = aero()
    Column(modifier.clip(RoundedCornerShape(18.dp)).background(if (c.glass) c.surface.copy(alpha = 0.82f) else c.surface)
        .border(1.dp, c.divider, RoundedCornerShape(18.dp)).padding(16.dp), content = content)
}

@Composable
fun AeroButton(text: String, modifier: Modifier = Modifier, primary: Boolean = true, enabled: Boolean = true, onClick: () -> Unit) {
    val c = aero()
    val bg = if (primary) c.accent else c.elevated
    val fg = if (primary) Color.Black else c.text
    Box(modifier.clip(RoundedCornerShape(14.dp)).background(if (enabled) bg else bg.copy(alpha = 0.4f))
        .then(AeroClick { if (enabled) onClick() }).padding(horizontal = 20.dp, vertical = 13.dp), contentAlignment = Alignment.Center) {
        Text(text, color = if (enabled) fg else fg.copy(alpha = 0.5f), fontWeight = FontWeight.Bold, fontSize = 14.sp)
    }
}

@Composable
fun AeroProgress(fraction: Float, modifier: Modifier = Modifier) {
    val c = aero()
    val anim by animateFloatAsState(fraction.coerceIn(0f, 1f), tween(if (LocalMotion.current) 300 else 0), label = "p")
    Box(modifier.height(8.dp).clip(RoundedCornerShape(4.dp)).background(c.elevated)) {
        Box(Modifier.fillMaxHeight().fillMaxWidth(anim).clip(RoundedCornerShape(4.dp)).background(c.accent))
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(text, modifier.padding(vertical = 8.dp), color = aero().text2, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.6.sp)
}

@Composable
fun EmptyState(icon: Int, title: String, body: String, action: (@Composable () -> Unit)? = null) {
    val c = aero()
    Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(painterResource(icon), null, tint = c.text2, modifier = Modifier.size(40.dp))
        Spacer(Modifier.height(12.dp))
        Text(title, color = c.text, fontWeight = FontWeight.SemiBold)
        if (body.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            Text(body, color = c.text2, fontSize = 13.sp, textAlign = TextAlign.Center)
        }
        if (action != null) { Spacer(Modifier.height(14.dp)); action() }
    }
}

@Composable
fun SwitchRow(title: String, checked: Boolean, subtitle: String? = null, onChange: (Boolean) -> Unit) {
    val c = aero()
    Row(Modifier.fillMaxWidth().then(AeroClick { onChange(!checked) }).padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = c.text, fontSize = 15.sp)
            if (subtitle != null) Text(subtitle, color = c.text2, fontSize = 12.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = c.accent, checkedThumbColor = Color.Black))
    }
}

@Composable
fun ClickRow(title: String, value: String? = null, onClick: () -> Unit) {
    val c = aero()
    Row(Modifier.fillMaxWidth().then(AeroClick(onClick)).padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = c.text, fontSize = 15.sp, modifier = Modifier.weight(1f))
        if (value != null) Text(value, color = c.accent, fontSize = 13.sp)
    }
}

@Composable
fun AeroDialog(title: String, body: @Composable ColumnScope.() -> Unit, confirm: String, onConfirm: () -> Unit,
              dismiss: String? = null, onDismiss: () -> Unit = onConfirm) {
    val c = aero()
    AlertDialog(onDismissRequest = onDismiss, containerColor = c.elevated, titleContentColor = c.text, textContentColor = c.text2,
        title = { Text(title, fontWeight = FontWeight.Bold) }, text = { Column { body() } },
        confirmButton = { TextButton(onClick = onConfirm) { Text(confirm, color = c.accent, fontWeight = FontWeight.Bold) } },
        dismissButton = dismiss?.let { { TextButton(onClick = onDismiss) { Text(it, color = c.text2) } } })
}

@Composable
fun StatusChip(text: String, active: Boolean) {
    val c = aero()
    Row(Modifier.clip(RoundedCornerShape(8.dp)).background(c.surface2).padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(6.dp).clip(RoundedCornerShape(3.dp)).background(if (active) c.accent else c.text2))
        Spacer(Modifier.width(6.dp))
        Text(text, color = c.text2, fontSize = 11.sp)
    }
}
