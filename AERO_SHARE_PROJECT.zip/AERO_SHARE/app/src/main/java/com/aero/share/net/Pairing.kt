package com.aero.share.net

import java.security.SecureRandom
import java.util.Base64
import java.util.concurrent.ConcurrentHashMap

class TokenStore(private val clock: () -> Long = System::currentTimeMillis) {
    private data class T(val expires: Long, var used: Boolean)
    private val tokens = ConcurrentHashMap<String, T>()
    private val rnd = SecureRandom()
    fun issue(ttlMs: Long): String {
        val b = ByteArray(16).also { rnd.nextBytes(it) }
        val s = Base64.getUrlEncoder().withoutPadding().encodeToString(b)
        tokens[s] = T(clock() + ttlMs, false)
        tokens.entries.removeIf { it.value.expires < clock() }
        return s
    }
    fun consume(s: String): Boolean {
        val t = tokens[s] ?: return false
        if (t.used || t.expires < clock()) { tokens.remove(s); return false }
        t.used = true; tokens.remove(s); return true
    }
}

data class QrPayload(val host: String, val port: Int, val token: String, val fp: String, val name: String) {
    fun encode(): String = "AERO1:$host:$port:$token:$fp:" +
        Base64.getUrlEncoder().withoutPadding().encodeToString(name.toByteArray(Charsets.UTF_8))
    companion object {
        fun decode(s: String): QrPayload? = runCatching {
            val p = s.trim().split(":")
            if (p.size != 6 || p[0] != "AERO1") return null
            val port = p[2].toInt()
            if (port !in 1..65535 || p[3].isEmpty() || p[4].length != 64) return null
            val name = String(Base64.getUrlDecoder().decode(p[5]), Charsets.UTF_8)
            QrPayload(p[1], port, p[3], p[4], name)
        }.getOrNull()
    }
}
