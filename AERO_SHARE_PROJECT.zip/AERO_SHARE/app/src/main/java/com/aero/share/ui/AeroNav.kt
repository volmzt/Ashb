package com.aero.share.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.aero.share.AeroApp
import com.aero.share.R
import com.aero.share.core.Formats
import com.aero.share.data.PowerMode
import com.aero.share.ui.screens.*

@Composable
fun AeroNav(app: AeroApp) {
    val nav = rememberNavController()
    val c = aero()
    val settings by app.settings.flow.collectAsStateWithLifecycle(initialValue = app.settingsNow)
    val back by nav.currentBackStackEntryAsState()
    val route = back?.destination?.route
    val fg = rememberFgFlag()

    val pairing by app.engine.pairing.collectAsStateWithLifecycle()
    pairing?.let { p ->
        AeroDialog(stringResource(R.string.pairing_title), body = {
            Text(stringResource(R.string.pairing_body, p.name))
            Spacer(Modifier.height(8.dp))
            Text(Formats.fpShort(p.fp), color = c.accent, fontSize = 18.sp, fontFamily = FontFamily.Monospace)
        }, confirm = stringResource(R.string.accept), onConfirm = { app.engine.answerPairing(true) },
            dismiss = stringResource(R.string.decline), onDismiss = { app.engine.answerPairing(false) })
    }

    Column(Modifier.fillMaxSize().background(c.bg).systemBarsPadding()) {
        Box(Modifier.weight(1f)) {
            NavHost(nav, startDestination = if (settings.onboarded) "home" else "onboarding") {
                composable("onboarding") { Onboarding(app, nav) }
                composable("home") { Home(app, nav) }
                composable("devices") { Devices(app, nav) }
                composable("settings") { Settings(app, nav) }
                composable("history") { History(app, nav) }
                composable("send") { SendPicker(app, nav) }
                composable("target") { SendTarget(app, nav) }
                composable("receive") { Receive(app, nav) }
                composable("scan") { QrScan(app, nav) }
                composable("transfer") { Transfer(app, nav) }
                composable("diagnostics") { Diagnostics(app, nav) }
            }
        }
        if (route in setOf("home", "devices", "settings")) {
            Row(Modifier.fillMaxWidth().background(c.surface).padding(vertical = 6.dp)) {
                listOf(Triple("home", R.string.nav_home, true), Triple("devices", R.string.nav_devices, false),
                    Triple("settings", R.string.nav_settings, true)).forEach { (r, label, useVector) ->
                    val sel = route == r
                    Column(Modifier.weight(1f).clip(RoundedCornerShape(12.dp))
                        .then(AeroClick { if (!sel) nav.navigate(r) { popUpTo("home"); launchSingleTop = true } })
                        .padding(vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        val tint = if (sel) c.accent else c.text2
                        when (r) {
                            "home" -> Icon(Icons.Filled.Home, null, tint = tint, modifier = Modifier.size(22.dp))
                            "settings" -> Icon(Icons.Filled.Settings, null, tint = tint, modifier = Modifier.size(22.dp))
                            else -> Icon(painterResource(R.drawable.ic_devices), null, tint = tint, modifier = Modifier.size(22.dp))
                        }
                        Text(stringResource(label), color = tint, fontSize = 11.sp)
                    }
                }
            }
        }
    }

    LaunchedEffect(fg) { app.engine.setForeground(fg) }
    val port by app.engine.serverPort.collectAsStateWithLifecycle()
    LaunchedEffect(fg, port, settings.visible, settings.startupDiscovery, settings.deviceName, settings.power, route) {
        val want = fg && settings.visible && settings.startupDiscovery && route in setOf("home", "devices", "target", "receive")
        if (want && port > 0) app.discovery.start(port, app.identity.name(settings.deviceName), true, settings.power == PowerMode.SAVING)
        else if (!want) app.discovery.stop()
    }
}

@Composable
fun rememberFgFlag(): Boolean {
    var fg by remember { mutableStateOf(true) }
    DisposableEffect(Unit) {
        val obs = object : DefaultLifecycleObserver {
            override fun onStart(owner: LifecycleOwner) { fg = true }
            override fun onStop(owner: LifecycleOwner) { fg = false }
        }
        val l = ProcessLifecycleOwner.get().lifecycle
        l.addObserver(obs)
        onDispose { l.removeObserver(obs) }
    }
    return fg
}
