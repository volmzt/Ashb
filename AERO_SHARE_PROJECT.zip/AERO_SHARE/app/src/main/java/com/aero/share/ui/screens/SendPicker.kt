package com.aero.share.ui.screens

import android.Manifest
import android.os.Build
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.aero.share.AeroApp
import com.aero.share.R
import com.aero.share.core.Formats
import com.aero.share.core.PathGuard
import com.aero.share.storage.*
import com.aero.share.ui.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

sealed class Sel(val key: String) {
    class One(val i: PickItem) : Sel(i.uri.toString())
    class Folder(val uri: android.net.Uri, val name: String) : Sel(uri.toString())
    class App(val e: AppEntry) : Sel(e.pkg)
}

class PickVm : ViewModel() {
    val sel = androidx.compose.runtime.mutableStateListOf<Sel>()
    var cat by mutableStateOf(Cat.RECENT)
    var apps by mutableStateOf(false)
}

@Composable
fun SendPicker(app: AeroApp, nav: NavController) {
    val c = aero(); val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    val vm: PickVm = viewModel()
    var items by remember { mutableStateOf<List<PickItem>>(emptyList()) }
    var appList by remember { mutableStateOf<List<AppEntry>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var rationale by remember { mutableStateOf(false) }
    var building by remember { mutableStateOf(false) }
    val perms = if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_AUDIO) else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    val mediaOk = perms.any { ContextCompat.checkSelfPermission(ctx, it) == android.content.pm.PackageManager.PERMISSION_GRANTED }
    val permL = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }
    val saf = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach { u -> runCatching {
            ctx.contentResolver.query(u, null, null, null, null)?.use { cu ->
                if (cu.moveToFirst()) {
                    val n = cu.getString(cu.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME))
                    val s = cu.getLong(cu.getColumnIndexOrThrow(OpenableColumns.SIZE))
                    vm.sel.add(Sel.One(PickItem(u, n, s, 0, ctx.contentResolver.getType(u) ?: "")))
                }
            }
        } }
    }
    val treeL = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { u ->
        if (u != null) {
            runCatching { ctx.contentResolver.takePersistableUriPermission(u, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            vm.sel.add(Sel.Folder(u, androidx.documentfile.provider.DocumentFile.fromTreeUri(ctx, u)?.name ?: "Folder"))
        }
    }
    LaunchedEffect(vm.cat, vm.apps, mediaOk) {
        if (vm.apps) { loading = true; appList = withContext(Dispatchers.IO) { Apks.list(ctx) }; loading = false }
        else if (mediaOk) { loading = true; items = withContext(Dispatchers.IO) { Catalog.items(ctx, vm.cat) }; loading = false }
    }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.then(AeroClick { nav.popBackStack() }).padding(8.dp)) { Icon(Icons.Filled.ArrowBack, null, tint = c.text) }
            Text(stringResource(R.string.send), color = c.text, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
        LazyRow(Modifier.padding(horizontal = 12.dp)) {
            val cats = listOf(Cat.RECENT to R.string.cat_recent, Cat.IMAGES to R.string.cat_images, Cat.VIDEOS to R.string.cat_videos,
                Cat.AUDIO to R.string.cat_audio, Cat.DOCS to R.string.cat_docs, Cat.DOWNLOADS to R.string.cat_downloads)
            items(cats) { (k, l) ->
                val s = !vm.apps && vm.cat == k
                Box(Modifier.padding(end = 6.dp).clip(RoundedCornerShape(10.dp)).background(if (s) c.accent else c.surface2)
                    .then(AeroClick { vm.apps = false; vm.cat = k; if (!mediaOk) rationale = true }).padding(horizontal = 14.dp, vertical = 8.dp)) {
                    Text(stringResource(l), color = if (s) Color.Black else c.text2, fontSize = 13.sp)
                }
            }
            item {
                Box(Modifier.clip(RoundedCornerShape(10.dp)).background(if (vm.apps) c.accent else c.surface2)
                    .then(AeroClick { vm.apps = true }).padding(horizontal = 14.dp, vertical = 8.dp)) {
                    Text(stringResource(R.string.cat_apps), color = if (vm.apps) Color.Black else c.text2, fontSize = 13.sp)
                }
            }
        }
        Row(Modifier.padding(12.dp)) {
            AeroButton(stringResource(R.string.pick_files), primary = false) { saf.launch(arrayOf("*/*")) }
            Spacer(Modifier.width(8.dp))
            AeroButton(stringResource(R.string.pick_folder), primary = false) { treeL.launch(null) }
        }
        if (!mediaOk && !vm.apps) EmptyState(R.drawable.ic_file, stringResource(R.string.permission_needed), stringResource(R.string.perm_media)) {
            AeroButton(stringResource(R.string.grant)) { permL.launch(perms) }
        } else if (loading) Box(Modifier.fillMaxWidth().padding(24.dp), Alignment.Center) { Text(stringResource(R.string.calculating), color = c.text2) }
        else LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            if (vm.apps) items(appList, key = { it.pkg }) { e ->
                val ch = vm.sel.any { it.key == e.pkg }
                Row(Modifier.fillMaxWidth().then(AeroClick { if (ch) vm.sel.removeAll { it.key == e.pkg } else vm.sel.add(Sel.App(e)) }).padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(painterResource(R.drawable.ic_apk), null, tint = c.text2, modifier = Modifier.size(32.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(e.label, color = c.text, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${e.version} · ${Formats.bytes(e.size)}", color = c.text2, fontSize = 12.sp)
                    }
                    if (ch) Icon(Icons.Filled.Check, null, tint = c.accent)
                }
            } else {
                if (items.isEmpty()) item { EmptyState(R.drawable.ic_file, stringResource(R.string.empty_category), "") }
                items(items, key = { it.uri.toString() }) { p ->
                    val ch = vm.sel.any { it.key == p.uri.toString() }
                    Row(Modifier.fillMaxWidth().then(AeroClick { if (ch) vm.sel.removeAll { it.key == p.uri.toString() } else vm.sel.add(Sel.One(p)) }).padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (p.mime.startsWith("image") || p.mime.startsWith("video")) AsyncImage(p.uri, null, Modifier.size(40.dp).clip(RoundedCornerShape(8.dp)), contentScale = ContentScale.Crop)
                        else Icon(painterResource(R.drawable.ic_file), null, tint = c.text2, modifier = Modifier.size(32.dp))
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(p.name, color = c.text, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(Formats.bytes(p.size), color = c.text2, fontSize = 12.sp)
                        }
                        if (ch) Icon(Icons.Filled.Check, null, tint = c.accent)
                    }
                }
            }
        }
        val quick = vm.sel.sumOf { when (it) { is Sel.One -> it.i.size; is Sel.App -> it.e.size; is Sel.Folder -> 0L } }
        Column(Modifier.fillMaxWidth().background(c.surface).padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(R.string.selected_summary, vm.sel.size, Formats.bytes(quick)), color = c.text, modifier = Modifier.weight(1f), fontSize = 14.sp)
                if (vm.sel.isNotEmpty()) AeroButton(stringResource(R.string.clear), primary = false) { vm.sel.clear() }
            }
            Spacer(Modifier.height(8.dp))
            AeroButton(stringResource(R.string.next), Modifier.fillMaxWidth(), enabled = vm.sel.isNotEmpty() && !building) {
                building = true
                scope.launch {
                    val files = withContext(Dispatchers.IO) {
                        vm.sel.flatMap { s -> when (s) {
                            is Sel.One -> listOf(OutFile(PathGuard.sanitizeRelative(s.i.name) ?: "file", s.i.size, uri = s.i.uri))
                            is Sel.Folder -> Catalog.folderFiles(ctx, s.uri)
                            is Sel.App -> Apks.appFiles(ctx, s.e)
                        } }
                    }
                    app.pendingFiles = files; app.pendingTotal = files.sumOf { it.size }; building = false
                    if (files.isNotEmpty()) { vm.sel.clear(); nav.navigate("target") }
                }
            }
        }
    }
    if (rationale) AeroDialog(stringResource(R.string.permission_needed), body = { Text(stringResource(R.string.perm_media)) },
        confirm = stringResource(R.string.grant), onConfirm = { rationale = false; permL.launch(perms) },
        dismiss = stringResource(R.string.use_system_picker), onDismiss = { rationale = false; saf.launch(arrayOf("*/*")) })
}
