package com.aero.share.core

object PathGuard {
    private val badChars = Regex("[\u0000-\u001f<>:\"|?*]")
    fun sanitizeRelative(path: String): String? {
        if (path.isBlank() || path.length > 512) return null
        val norm = path.replace('\\', '/')
        if (norm.startsWith("/") || norm.contains(":")) return null
        val parts = norm.split('/').filter { it.isNotEmpty() && it != "." }
        if (parts.isEmpty()) return null
        if (parts.any { it == ".." || badChars.containsMatchIn(it) || it.length > 200 }) return null
        return parts.joinToString("/")
    }
    fun uniqueName(name: String, taken: Set<String>): String {
        if (name !in taken) return name
        val dot = name.lastIndexOf('.')
        val base = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var i = 1
        while ("$base ($i)$ext" in taken) i++
        return "$base ($i)$ext"
    }
}
