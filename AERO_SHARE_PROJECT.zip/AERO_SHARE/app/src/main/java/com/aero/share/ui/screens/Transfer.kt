package com.aero.share.ui.screens

import android.app.DownloadManager
import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.aero.share.AeroApp
import com.aero.share.R
import com.aero.share.core.Formats
import com.aero.share.net.Dir
import com.aero.share.net.TState
import com.aero.share.storage.ApkInfo
import com.aero.share.storage.Apks
import com.aero.share.ui.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun Transfer(app: AeroApp, nav: NavController) {
    val c = aero(); val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    val s by app.engine.active.collectAsStateWithLifecycle()
    var info by remember { mutableStateOf<ApkInfo?>(null) }
    val session = s ?: run { LaunchedEffect(Unit) { nav.popBackStack() }; return }
    val label = when (session.state) {
        TState.Waiting -> R.string.st_waiting; TState.Preparing -> R.string.st_waiting
        TState.Connecting -> R.string.st_connecting; TState.Transferring -> R.string.st_transferring
        TState.Paused -> R.string.st_paused; TState.Interrupted -> R.string.st_interrupted
        TState.Verifying -> R.string.st_verifying; TState.Completed -> R.string.st_completed
        TState.Failed -> R.string.st_failed; TState.Cancelled -> R.string.st_cancelled
    }
    val eta = if (session.speed > 0 && session.totalBytes > session.doneBytes) Formats.duration((session.totalBytes - session.doneBytes) * 1000 / session.speed) else null
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(painterResource(R.drawable.ic_logo), null, tint = c.accent, modifier = Modifier.size(26.dp))
            Spacer(Modifier.width(8.dp))
            Text(stringResource(R.string.app_name), color = c.text, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(20.dp))
        Text(stringResource(label), color = if (session.state == TState.Failed || session.state == TState.Interrupted) c.danger else c.text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(session.peerName, color = c.text2)
        Spacer(Modifier.height(16.dp))
        AeroProgress(if (session.totalBytes > 0) session.doneBytes.toFloat() / session.totalBytes else 0f, Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        Text("${Formats.bytes(session.doneBytes)} / ${Formats.bytes(session.totalBytes)}", color = c.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        if (session.state == TState.Transferring) {
            Text(Formats.speed(session.speed), color = c.accent, fontSize = 14.sp)
            if (eta != null) Text(stringResource(R.string.eta_approx, eta), color = c.text2, fontSize = 13.sp)
            Text(stringResource(R.string.file_x_of_y, session.fileIndex, session.fileCount), color = c.text2, fontSize = 13.sp)
            if (session.fileName.isNotEmpty()) Text(session.fileName, color = c.text2, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Text(stringResource(R.string.local_tls), color = c.text2, fontSize = 12.sp)
        session.errCode?.let { code ->
            val res = ctx.resources.getIdentifier(code, "string", ctx.packageName)
            if (res != 0) Text(stringResource(res), color = c.danger, fontSize = 13.sp)
        }
        Spacer(Modifier.height(16.dp))
        when {
            session.state == TState.Transferring || session.state == TState.Connecting || session.state == TState.Waiting -> Row {
                if (session.dir == Dir.Send && session.state == TState.Transferring) { AeroButton(stringResource(R.string.pause), primary = false) { app.engine.pause() }; Spacer(Modifier.width(8.dp)) }
                AeroButton(stringResource(R.string.cancel), primary = false) { app.engine.cancel() }
            }
            session.state == TState.Paused && session.dir == Dir.Send -> Row {
                AeroButton(stringResource(R.string.resume)) { app.engine.resume() }
                Spacer(Modifier.width(8.dp))
                AeroButton(stringResource(R.string.cancel), primary = false) { app.engine.cancel() }
            }
            session.terminal -> {
                Text(stringResource(R.string.duration_label, Formats.duration(session.endedAt - session.startedAt)), color = c.text2, fontSize = 13.sp)
                if (session.results.any { it.name == "aero-app.json" }) Text(stringResource(R.string.apk_split_note), color = c.text2, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                if (session.state == TState.Completed && session.dir == Dir.Receive && session.results.isNotEmpty()) {
                    LazyColumn(Modifier.weight(1f, fill = false)) {
                        items(session.results, key = { it.uri.toString() }) { f ->
                            AeroCard(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                                Text(f.name, color = c.text, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(Formats.bytes(f.size), color = c.text2, fontSize = 12.sp)
                                Row {
                                    AeroButton(stringResource(R.string.open), primary = false) { runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW).apply { setDataAndType(f.uri, f.mime); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }) } }
                                    if (f.name.endsWith(".apk")) {
                                        Spacer(Modifier.width(6.dp))
                                        AeroButton(stringResource(R.string.install), primary = false) { runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW).apply { setDataAndType(f.uri, "application/vnd.android.package-archive"); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }) } }
                                        Spacer(Modifier.width(6.dp))
                                        AeroButton(stringResource(R.string.details), primary = false) { scope.launch { info = withContext(Dispatchers.IO) { Apks.archiveInfo(ctx, f.uri) } } }
                                    }
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    AeroButton(stringResource(R.string.open_folder), primary = false) { runCatching { ctx.startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)) } }
                }
                Spacer(Modifier.height(12.dp))
                AeroButton(stringResource(R.string.close), Modifier.fillMaxWidth()) { app.engine.dismissTerminal(); nav.navigate("home") { popUpTo("home") { inclusive = true } } }
            }
            else -> AeroButton(stringResource(R.string.close), primary = false) { app.engine.dismissTerminal(); nav.popBackStack() }
        }
    }
    info?.let { i ->
        AeroDialog(i.label, body = {
            Text("${stringResource(R.string.package_name)}: ${i.pkg}")
            Text("${stringResource(R.string.version)}: ${i.version}")
            Text("${stringResource(R.string.sha256)}: ${i.sha256.take(24)}…", fontSize = 12.sp)
            if (i.signer != null) Text("${stringResource(R.string.signer)}: ${i.signer.take(24)}…", fontSize = 12.sp)
        }, confirm = stringResource(R.string.close), onConfirm = { info = null })
    }
}
