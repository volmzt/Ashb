package com.aero.share.storage

import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.documentfile.provider.DocumentFile
import com.aero.share.core.PathGuard
import java.io.File
import java.io.FileInputStream
import java.io.InputStream
import java.util.UUID

data class OutFile(val path: String, val size: Long, val uri: Uri? = null, val file: File? = null) {
    val id: String = UUID.randomUUID().toString()
    fun open(ctx: Context): InputStream =
        uri?.let { ctx.contentResolver.openInputStream(it)!! } ?: FileInputStream(file!!)
}

data class PickItem(val uri: Uri, val name: String, val size: Long, val date: Long, val mime: String)
enum class Cat { RECENT, IMAGES, VIDEOS, AUDIO, DOCS, DOWNLOADS }

object Catalog {
    fun items(ctx: Context, cat: Cat): List<PickItem> {
        val coll = MediaStore.Files.getContentUri("external")
        val proj = arrayOf(
            MediaStore.Files.FileColumns._ID, MediaStore.Files.FileColumns.DISPLAY_NAME,
            MediaStore.Files.FileColumns.SIZE, MediaStore.Files.FileColumns.DATE_MODIFIED,
            MediaStore.Files.FileColumns.MIME_TYPE
        )
        val sel = StringBuilder("${MediaStore.Files.FileColumns.SIZE} > 0")
        when (cat) {
            Cat.IMAGES -> sel.append(" AND ${MediaStore.Files.FileColumns.MEDIA_TYPE} = ${MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE}")
            Cat.VIDEOS -> sel.append(" AND ${MediaStore.Files.FileColumns.MEDIA_TYPE} = ${MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO}")
            Cat.AUDIO -> sel.append(" AND ${MediaStore.Files.FileColumns.MEDIA_TYPE} = ${MediaStore.Files.FileColumns.MEDIA_TYPE_AUDIO}")
            Cat.DOCS -> sel.append(" AND (${MediaStore.Files.FileColumns.MIME_TYPE} LIKE 'application/%' OR ${MediaStore.Files.FileColumns.MIME_TYPE} LIKE 'text/%')")
            Cat.DOWNLOADS -> if (Build.VERSION.SDK_INT >= 29)
                sel.append(" AND ${MediaStore.Files.FileColumns.RELATIVE_PATH} LIKE 'Download/%'")
            else
                @Suppress("DEPRECATION")
                sel.append(" AND ${MediaStore.Files.FileColumns.DATA} LIKE '%/Download/%'")
            Cat.RECENT -> {}
        }
        val out = ArrayList<PickItem>()
        runCatching {
            ctx.contentResolver.query(coll, proj, sel.toString(), null,
                "${MediaStore.Files.FileColumns.DATE_MODIFIED} DESC LIMIT 300")?.use { c ->
                val iId = c.getColumnIndexOrThrow(proj[0]); val iN = c.getColumnIndexOrThrow(proj[1])
                val iS = c.getColumnIndexOrThrow(proj[2]); val iD = c.getColumnIndexOrThrow(proj[3])
                val iM = c.getColumnIndexOrThrow(proj[4])
                while (c.moveToNext()) {
                    val uri = Uri.withAppendedPath(coll, c.getLong(iId).toString())
                    out.add(PickItem(uri, c.getString(iN) ?: "file", c.getLong(iS), c.getLong(iD) * 1000, c.getString(iM) ?: ""))
                }
            }
        }
        return out
    }

    fun folderFiles(ctx: Context, tree: Uri): List<OutFile> {
        val root = DocumentFile.fromTreeUri(ctx, tree) ?: return emptyList()
        val rootName = PathGuard.sanitizeRelative(root.name ?: "Folder") ?: "Folder"
        val out = ArrayList<OutFile>()
        fun walk(d: DocumentFile, rel: String) {
            for (f in d.listFiles()) {
                val safe = PathGuard.sanitizeRelative(f.name ?: continue) ?: continue
                val p = "$rel/$safe"
                if (f.isDirectory) walk(f, p)
                else if (f.isFile) out.add(OutFile(p, f.length(), uri = f.uri))
            }
        }
        walk(root, rootName)
        return out
    }
}
