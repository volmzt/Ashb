package com.aero.share.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.aero.share.AeroApp
import com.aero.share.MainActivity
import com.aero.share.R
import com.aero.share.core.Formats
import com.aero.share.net.Dir
import com.aero.share.net.TState
import kotlinx.coroutines.*

class TransferService : Service() {
    companion object {
        const val CH_TRANSFER = "transfers"; const val CH_INCOMING = "incoming"
        const val N_PROGRESS = 1; const val N_INCOMING = 2
        const val ACTION_CANCEL = "com.aero.share.CANCEL"
        fun createChannels(ctx: Context) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CH_TRANSFER, ctx.getString(R.string.channel_transfers), NotificationManager.IMPORTANCE_LOW))
            nm.createNotificationChannel(NotificationChannel(CH_INCOMING, ctx.getString(R.string.channel_incoming), NotificationManager.IMPORTANCE_HIGH))
        }
        fun sync(ctx: Context) {
            val app = ctx.applicationContext as AeroApp
            val s = app.engine.active.value
            if (app.engine.receiveMode.value || (s != null && !s.terminal))
                ContextCompat.startForegroundService(ctx, Intent(ctx, TransferService::class.java))
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var loopJob: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CANCEL) { (application as AeroApp).engine.cancel(); return START_NOT_STICKY }
        val type = if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC else 0
        ServiceCompat.startForeground(this, N_PROGRESS, buildProgress(), type)
        if (loopJob == null) loopJob = scope.launch {
            val app = application as AeroApp
            var last = 0L
            while (isActive) {
                val s = app.engine.active.value
                val nm = getSystemService(NotificationManager::class.java)
                val now = System.currentTimeMillis()
                if (now - last > 900) {
                    last = now
                    if (app.settingsNow.notifications && app.settingsNow.progressNotif) nm.notify(N_PROGRESS, buildProgress())
                }
                val inc = app.engine.incoming.value
                if (inc != null && app.settingsNow.notifications) {
                    val pi = PendingIntent.getActivity(this@TransferService, 0, Intent(this@TransferService, MainActivity::class.java),
                        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
                    nm.notify(N_INCOMING, NotificationCompat.Builder(this@TransferService, CH_INCOMING)
                        .setSmallIcon(R.drawable.ic_receive).setContentTitle(getString(R.string.incoming_title))
                        .setContentText(getString(R.string.notif_incoming, inc.peerName))
                        .setContentIntent(pi).setAutoCancel(true).build())
                } else nm.cancel(N_INCOMING)
                if (s == null && !app.engine.receiveMode.value) {
                    ServiceCompat.stopForeground(this@TransferService, ServiceCompat.STOP_FOREGROUND_REMOVE)
                    stopSelf(); return@launch
                }
                delay(500)
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() { scope.cancel(); super.onDestroy() }

    private fun buildProgress(): Notification {
        val app = application as AeroApp
        val s = app.engine.active.value
        val title: String; val text: String; var progress = 0; var indet = false
        when {
            s != null && (s.state == TState.Transferring || s.state == TState.Verifying) -> {
                title = getString(if (s.dir == Dir.Send) R.string.notif_sending else R.string.notif_receiving)
                text = "${Formats.bytes(s.doneBytes)} / ${Formats.bytes(s.totalBytes)} · ${Formats.speed(s.speed)}"
                progress = if (s.totalBytes > 0) (s.doneBytes * 1000 / s.totalBytes).toInt() else 0
            }
            s?.state == TState.Completed -> { title = getString(R.string.notif_done); text = s.peerName }
            s?.state == TState.Failed || s?.state == TState.Interrupted -> { title = getString(R.string.notif_failed); text = s.peerName }
            else -> { title = getString(R.string.app_name); text = getString(R.string.notif_waiting); indet = true }
        }
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val cancel = PendingIntent.getService(this, 1, Intent(this, TransferService::class.java).setAction(ACTION_CANCEL),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val b = NotificationCompat.Builder(this, CH_TRANSFER)
            .setSmallIcon(R.drawable.ic_logo).setContentTitle(title).setContentText(text)
            .setContentIntent(pi).setOngoing(true).setOnlyAlertOnce(true)
        if (s != null && !s.terminal) b.addAction(R.drawable.ic_pause, getString(R.string.cancel), cancel)
        if (indet) b.setProgress(0, 0, true) else b.setProgress(1000, progress, false)
        return b.build()
    }
}
