package com.aero.share.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

enum class ThemeMode { SYSTEM, DARK, LIGHT }
enum class PowerMode { BALANCED, PERFORMANCE, SAVING }
enum class ConflictMode { RENAME, SKIP }

data class AppSettings(
    val onboarded: Boolean = false,
    val theme: ThemeMode = ThemeMode.SYSTEM,
    val accent: String = "orange",
    val language: String = "",
    val deviceName: String = "",
    val visible: Boolean = true,
    val startupDiscovery: Boolean = true,
    val receiveTreeUri: String = "",
    val notifications: Boolean = true,
    val progressNotif: Boolean = true,
    val autoAcceptTrusted: Boolean = false,
    val power: PowerMode = PowerMode.BALANCED,
    val animations: Boolean = true,
    val haptics: Boolean = true,
    val sound: Boolean = true,
    val glass: Boolean = false,
    val timeoutSec: Int = 10,
    val qrTtlMin: Int = 5,
    val conflict: ConflictMode = ConflictMode.RENAME,
    val cleanupTemp: Boolean = true,
    val warnLarge: Boolean = true
) {
    fun chunkSize(): Int = when (power) {
        PowerMode.PERFORMANCE -> 1 shl 20
        PowerMode.BALANCED -> 256 * 1024
        PowerMode.SAVING -> 64 * 1024
    }
}

private val Context.ds by preferencesDataStore("aero_settings")

class SettingsStore(private val ctx: Context) {
    private object Keys {
        val ONB = booleanPreferencesKey("onb")
        val THEME = stringPreferencesKey("theme")
        val ACCENT = stringPreferencesKey("accent")
        val LANG = stringPreferencesKey("lang")
        val NAME = stringPreferencesKey("name")
        val VIS = booleanPreferencesKey("vis")
        val START = booleanPreferencesKey("start")
        val TREE = stringPreferencesKey("tree")
        val NOTIF = booleanPreferencesKey("notif")
        val PNOTIF = booleanPreferencesKey("pnotif")
        val AUTO = booleanPreferencesKey("auto")
        val POWER = stringPreferencesKey("power")
        val ANIM = booleanPreferencesKey("anim")
        val HAP = booleanPreferencesKey("hap")
        val SND = booleanPreferencesKey("snd")
        val GLASS = booleanPreferencesKey("glass")
        val TMO = intPreferencesKey("tmo")
        val TTL = intPreferencesKey("ttl")
        val CONF = stringPreferencesKey("conf")
        val CLEAN = booleanPreferencesKey("clean")
        val WARN = booleanPreferencesKey("warn")
    }
    val flow: Flow<AppSettings> = ctx.ds.data.catch { e ->
        if (e is IOException) emit(emptyPreferences()) else throw e
    }.map { p ->
        AppSettings(
            onboarded = p[Keys.ONB] ?: false,
            theme = runCatching { ThemeMode.valueOf(p[Keys.THEME] ?: "SYSTEM") }.getOrDefault(ThemeMode.SYSTEM),
            accent = p[Keys.ACCENT] ?: "orange",
            language = p[Keys.LANG] ?: "",
            deviceName = p[Keys.NAME] ?: "",
            visible = p[Keys.VIS] ?: true,
            startupDiscovery = p[Keys.START] ?: true,
            receiveTreeUri = p[Keys.TREE] ?: "",
            notifications = p[Keys.NOTIF] ?: true,
            progressNotif = p[Keys.PNOTIF] ?: true,
            autoAcceptTrusted = p[Keys.AUTO] ?: false,
            power = runCatching { PowerMode.valueOf(p[Keys.POWER] ?: "BALANCED") }.getOrDefault(PowerMode.BALANCED),
            animations = p[Keys.ANIM] ?: true,
            haptics = p[Keys.HAP] ?: true,
            sound = p[Keys.SND] ?: true,
            glass = p[Keys.GLASS] ?: false,
            timeoutSec = p[Keys.TMO] ?: 10,
            qrTtlMin = p[Keys.TTL] ?: 5,
            conflict = runCatching { ConflictMode.valueOf(p[Keys.CONF] ?: "RENAME") }.getOrDefault(ConflictMode.RENAME),
            cleanupTemp = p[Keys.CLEAN] ?: true,
            warnLarge = p[Keys.WARN] ?: true
        )
    }
    private suspend fun edit(block: (MutablePreferences) -> Unit) { ctx.ds.edit { block(it) } }
    suspend fun setOnboarded() = edit { it[Keys.ONB] = true }
    suspend fun setTheme(v: ThemeMode) = edit { it[Keys.THEME] = v.name }
    suspend fun setAccent(v: String) = edit { it[Keys.ACCENT] = v }
    suspend fun setLanguage(v: String) = edit { it[Keys.LANG] = v }
    suspend fun setDeviceName(v: String) = edit { it[Keys.NAME] = v.trim().take(40) }
    suspend fun setVisible(v: Boolean) = edit { it[Keys.VIS] = v }
    suspend fun setStartupDiscovery(v: Boolean) = edit { it[Keys.START] = v }
    suspend fun setTree(v: String) = edit { it[Keys.TREE] = v }
    suspend fun setNotifications(v: Boolean) = edit { it[Keys.NOTIF] = v }
    suspend fun setProgressNotif(v: Boolean) = edit { it[Keys.PNOTIF] = v }
    suspend fun setAutoAccept(v: Boolean) = edit { it[Keys.AUTO] = v }
    suspend fun setPower(v: PowerMode) = edit { it[Keys.POWER] = v.name }
    suspend fun setAnimations(v: Boolean) = edit { it[Keys.ANIM] = v }
    suspend fun setHaptics(v: Boolean) = edit { it[Keys.HAP] = v }
    suspend fun setSound(v: Boolean) = edit { it[Keys.SND] = v }
    suspend fun setGlass(v: Boolean) = edit { it[Keys.GLASS] = v }
    suspend fun setTimeout(v: Int) = edit { it[Keys.TMO] = v }
    suspend fun setQrTtl(v: Int) = edit { it[Keys.TTL] = v }
    suspend fun setConflict(v: ConflictMode) = edit { it[Keys.CONF] = v.name }
    suspend fun setCleanup(v: Boolean) = edit { it[Keys.CLEAN] = v }
    suspend fun setWarnLarge(v: Boolean) = edit { it[Keys.WARN] = v }
}
