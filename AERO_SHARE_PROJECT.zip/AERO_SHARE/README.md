# AERO SHARE

Share without limits. Direct, encrypted file sharing between nearby Android devices.
Free. No ads. No accounts. No cloud. Developer: **AERO**.

## Works in v1.0 (real implementations, no mockups)

- **Discovery:** mDNS/DNS-SD via `NsdManager` with a multicast lock. Real devices only.
- **Transport:** local Wi-Fi LAN or hotspot (QR / manual address). TLS-encrypted TCP:
  TLS 1.3 on Android 10+, TLS 1.2 ECDHE-ECDSA-AES-GCM on Android 8-9.
- **Security:** per-device ECDSA P-256 key in AndroidKeyStore (non-exportable), self-signed
  certificate (BouncyCastle), certificate pinning. Unknown devices confirmed by a short code;
  QR carries host, port, fingerprint and a single-use expiring token. Incoming transfers always
  need confirmation unless the device is trusted AND auto-accept was explicitly enabled.
- **Transfers:** multiple files, folders (SAF, structure preserved), installed apps (base + all
  split APKs + metadata), streaming I/O with `Long` sizes, buffers 64 KB / 256 KB / 1 MB by power
  mode, per-file SHA-256, path-traversal validation, conflict rename/skip, pending MediaStore
  writes with atomic finalization, storage checks, sequential queue, cancel, pause/resume at
  file boundaries, foreground service with progress and cancel action.
- **Storage:** `Downloads/AERO SHARE/` (MediaStore on 10+, direct path on 8-9) or any SAF tree.
  Received APKs open only through the system installer.
- **UI:** custom AERO design system, dark/light/system, 4 accents, optional translucent cards,
  reduced-motion aware, onboarding, Home/Devices/Settings, history with filters, diagnostics
  with export, full EN/UK/RU localization and per-app language switch.

## Honest limitations (roadmap, not shown as working features)

Wi-Fi Direct, Bluetooth-assisted discovery, automatic hotspot creation, mid-file resume,
multiple simultaneous recipients, compression, internet relay, plugins.
Split-APK installation needs a split installer (SAI) or adb; all parts are transferred.
mDNS can be blocked by router client isolation or unavailable on some hotspot interfaces —
QR / manual address works in those cases. Force-stop or OEM battery killers can stop background
execution; the app never claims otherwise.

## Build

CI: repository root holds the project ZIP and `.github/workflows/build.yml`. The workflow
extracts (or generates from `parts/`), creates the Gradle wrapper, runs unit tests, builds
`app-debug.apk` and uploads it as an artifact.

Android Studio: open the extracted `AERO_SHARE/` folder. AGP 8.7.3, Gradle 8.9, Kotlin 2.0.21,
compileSdk 35, minSdk 26, JDK 17.

## Architecture

Single `:app` module with clean package boundaries: `core` (pure utils, unit-tested),
`data` (Room + DataStore), `net` (protocol, TLS identity, discovery, engine), `storage`
(catalog, APKs, receiver), `service` (foreground service), `ui` (design system + screens).

## Wire protocol v1

TLS mutual auth -> `HELLO` both ways -> `REQ` (manifest) -> `ACC` -> per file:
`FILE`, raw bytes (size from manifest), `END{sha256}`, `ACK` -> `DONE` / `DONE_ACK`.
`PAUSE` / `CANCEL` between files. Control frames: 4-byte BE length + UTF-8 JSON.

## Permissions

Requested only at point of use: media read (picker categories, SAF fallback needs none),
camera (QR only), notifications (progress), storage write on Android 8-9 only,
foreground service (background transfers). Package visibility: launchable apps only.

## Testing

Automated: unit tests for path validation, protocol framing and Long sizes, QR payload,
token single-use/expiry, streaming SHA-256, formatting. `./gradlew testDebugUnitTest`.

Physical devices (required before production): two phones on one Wi-Fi; Wi-Fi without internet;
hotspot + QR; Bluetooth off; low storage; weak device; Android 8/10/14+; disconnect mid-transfer;
minimize; screen off; cancel; name conflict; corrupted hash (must never report success).

## Licenses

AndroidX / Kotlin / Compose / Room / Coil / CameraX / ZXing (Apache 2.0), BouncyCastle (MIT-style).
No analytics, no tracking, no ads. Nothing leaves your devices.
